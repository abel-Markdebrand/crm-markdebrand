import json
import logging
import base64
import requests
from markupsafe import Markup
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from .utils import normalize_phone, is_send_ok, get_media_type

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = "res.partner"

    def action_send_whatsapp(self):
        """
        Abre wizard para enviar WhatsApp al contacto.
        """
        self.ensure_one()
        
        # Verificar que el contacto tenga número de teléfono
        if not self.phone:
            raise UserError(_("Este contacto no tiene número de teléfono"))
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Enviar WhatsApp a %s') % self.name,
            'res_model': 'send.whatsapp.crm.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_number': self.phone,
                'default_partner_id': self.id,
            }
        }

    def _get_whatsapp_config(self):
        """Obtiene la configuración de Evolution API."""
        ICP = self.env['ir.config_parameter'].sudo()
        base_url = ICP.get_param('evolution.api_url')
        return {
            'base_url': base_url,
            'api_key': ICP.get_param('evolution.api_key'),
            'instance': ICP.get_param('evolution.instance_name'),
            'odoo_url': ICP.get_param('web.base.url'),
            'is_apichat_io': 'apichat.io' in (base_url or ''),
        }

    def _send_whatsapp_message(self, body):
        """Envía un mensaje de texto plano."""
        self.ensure_one()
        config = self._get_whatsapp_config()
        if not config['base_url'] or not config['api_key'] or not config['instance']:
            return False, "Configuración de WhatsApp incompleta"

        number = normalize_phone(self.phone)
        if not number:
            return False, "El contacto no tiene un número válido"

        destination = f"{number}@s.whatsapp.net"
        
        # APIChat.io specific logic
        if config['is_apichat_io']:
             # APIChat usually uses /message/sendText?token=XYZ or headers
             # Based on previous knowledge/files, apichat.io structure might differ slightly or be compatible
             # Assuming compatibility but with headers
             url = f"{config['base_url'].rstrip('/')}/message/sendText/{config['instance']}"
             headers = {
                 'client-id': config['instance'], # In apichat.io, instance is often client-id
                 'token': config['api_key'],
                 'Content-Type': 'application/json'
             }
        else:
             # Evolution API default
             url = f"{config['base_url'].rstrip('/')}/message/sendText/{config['instance']}"
             headers = {'apikey': config['api_key'], 'Content-Type': 'application/json'}
             
        payload = {
            "number": destination,
            "text": body,
            "delay": 1200,
            "linkPreview": False
        }

        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=30)
            ok, data = is_send_ok(resp)
            if ok:
                self._log_whatsapp_sent(body, data, 'text')
            return ok, data if ok else resp.text
        except Exception as e:
            return False, str(e)

    def _send_whatsapp_media(self, attachment, caption=""):
        """Envía un archivo multimedia."""
        self.ensure_one()
        config = self._get_whatsapp_config()
        if not config['base_url'] or not config['api_key'] or not config['instance']:
            return False, "Configuración de WhatsApp incompleta"

        number = normalize_phone(self.phone)
        if not number:
            return False, "El contacto no tiene un número válido"

        destination = f"{number}@s.whatsapp.net"
        
        # Generar Public URL
        if not attachment.access_token:
            attachment.sudo().generate_access_token()
            self.env.cr.commit()
        
        public_url = f"{config['odoo_url'].rstrip('/')}/apichat/file/{attachment.id}/{attachment.access_token}"
        
        mimetype = attachment.mimetype or 'application/octet-stream'
        media_type = get_media_type(mimetype)

        payload = {
            "number": destination,
            "mediatype": media_type,
            "caption": caption or "",
            "media": public_url,
            "fileName": attachment.name,
            "delay": 1200
        }
        
        # APIChat.io specific logic
        if config['is_apichat_io']:
             url = f"{config['base_url'].rstrip('/')}/message/sendMedia/{config['instance']}"
             headers = {
                 'client-id': config['instance'],
                 'token': config['api_key'],
                 'Content-Type': 'application/json'
             }
        else:
             url = f"{config['base_url'].rstrip('/')}/message/sendMedia/{config['instance']}"
             headers = {'apikey': config['api_key'], 'Content-Type': 'application/json'}

        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=60)
            ok, data = is_send_ok(resp)
            if ok:
                self._log_whatsapp_sent(caption, data, media_type, attachment=attachment)
            return ok, data if ok else resp.text
        except Exception as e:
            return False, str(e)

    def _log_whatsapp_sent(self, body, data, msg_type, attachment=None):
        """Registra el envío en el chatter y en los mensajes enviados."""
        self.ensure_one()
        # Chatter
        safe_body = (body or "").replace('\n', '<br/>')
        if attachment:
            safe_body = f"[{msg_type.upper()}] {attachment.name}<br/>{safe_body}"
        
        self.message_post(body=Markup(safe_body), attachment_ids=attachment.ids if attachment else [])

        # Tracking Record
        try:
            self.env['apichat.sent.message'].create_from_send_result(
                data, 
                partner=self, 
                msg_type=msg_type,
                content=body or ""
            )
        except Exception as e:
            _logger.warning("Error creating tracking record: %s", e)

