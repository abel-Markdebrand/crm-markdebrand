# -*- coding: utf-8 -*-
from odoo import models
import logging
_logger = logging.getLogger(__name__)

class SendWhatsappCrmWizardCompat(models.TransientModel):
    _inherit = 'send.whatsapp.crm.wizard'

    def action_send(self):
        """Compatibilidad para el botón de la vista.
        - Si el modelo original ya tiene action_send: lo llama (super()).
        - Si no, delega a cualquiera de los métodos habituales si existen.
        - Si no hay ninguno, cierra el wizard (no rompe la instalación).
        """
        # 1) Si el modelo base ya define action_send, usamos ese
        try:
            return super(SendWhatsappCrmWizardCompat, self).action_send()
        except AttributeError:
            # el modelo original no define action_send -> seguimos
            pass

        # 2) Delegar a métodos comunes que puedas tener en tu wizard real
        for meth in ('action_send_whatsapp', 'action_send_message', 'send', 'button_send'):
            if hasattr(self, meth):
                _logger.info("🔁 [Compat] action_send delega a %s()", meth)
                return getattr(self, meth)()

        _logger.warning("⚠️ [Compat] action_send no encontró implementación; cerrando wizard.")
        return {'type': 'ir.actions.act_window_close'}