# -*- coding: utf-8 -*-
import logging
import requests
import time
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

DEFAULT_WEBHOOK_URL = 'https://n8n-n8n.vdsomb.easypanel.host/webhook/2967d654-26b0-43fe-9edb-60d137db2f59'


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    # Evolution API Credentials
    evolution_api_url = fields.Char(
        string='Evolution API URL',
        config_parameter='evolution.api_url',
        help='URL base de tu instancia Evolution API (ej: https://api.midominio.com)',
        default='http://localhost:8080'
    )
    evolution_api_key = fields.Char(
        string='Global API Key / Token',
        config_parameter='evolution.api_key',
        help='API Key Global configurada en Evolution API',
        password=True
    )
    evolution_instance_name = fields.Char(
        string='Nombre de Instancia',
        config_parameter='evolution.instance_name',
        help='Nombre de la instancia creada en Evolution API',
        default='mi_instancia'
    )

    
    # Webhook Configuration
    apichat_webhook_token = fields.Char(
        string='Token de Webhook',
        config_parameter='apichat.webhook_token',
        help='Token de seguridad para verificar peticiones entrantes. Añadir ?token=XYZ a la URL.',
        password=True
    )
    
    apichat_webhook_url = fields.Char(
        string='URL del Webhook n8n',
        config_parameter='apichat.webhook_url',
        help='URL del webhook de n8n donde se enviarán los mensajes recibidos'
    )
    
    apichat_webhook_auto_forward = fields.Boolean(
        string='Auto-Forward a Webhook',
        config_parameter='apichat.webhook_auto_forward',
        default=False,
        help='Enviar automáticamente los mensajes recibidos al webhook al momento de recibirlos'
    )
    
    apichat_webhook_timeout = fields.Integer(
        string='Timeout (segundos)',
        config_parameter='apichat.webhook_timeout',
        default=20,
        help='Tiempo máximo de espera para la respuesta del webhook'
    )
    
    apichat_webhook_verify_ssl = fields.Boolean(
        string='Verificar SSL',
        config_parameter='apichat.webhook_verify_ssl',
        default=True,
        help='Verificar certificados SSL al conectar con el webhook'
    )
    
    apichat_webhook_force_json = fields.Boolean(
        string='Forzar formato JSON',
        config_parameter='apichat.webhook_force_json',
        default=True,
        help='Si los datos no son JSON válido, envolver como {"raw_text": "..."}'
    )
    
    # Configuración de Grupos de WhatsApp
    apichat_groups_enabled = fields.Boolean(
        string='Habilitar Grupos',
        config_parameter='apichat.groups_enabled',
        default=False,
        help='Permite enviar/recibir mensajes a través de grupos de WhatsApp'
    )

    @api.constrains('apichat_webhook_url')
    def _check_webhook_url(self):
        """Valida que la URL del webhook sea válida."""
        for rec in self:
            if rec.apichat_webhook_url:
                url = rec.apichat_webhook_url.strip()
                if url and not url.startswith(('http://', 'https://')):
                    raise ValidationError(_("La URL del webhook debe comenzar con http:// o https://"))

    @api.constrains('apichat_webhook_timeout')
    def _check_webhook_timeout(self):
        """Valida que el timeout sea razonable."""
        for rec in self:
            if rec.apichat_webhook_timeout:
                if rec.apichat_webhook_timeout < 1:
                    raise ValidationError(_("El timeout debe ser mayor a 0 segundos"))
                if rec.apichat_webhook_timeout > 120:
                    raise ValidationError(_("El timeout no puede ser mayor a 120 segundos"))

    def action_test_apichat_connection(self):
        """Prueba la conexión con la API de Evolution API o APIChat.io."""
        self.ensure_one()
        
        # Guardar valores actuales antes de probar
        self.set_values()
        
        base_url = self.env['ir.config_parameter'].sudo().get_param('evolution.api_url')
        api_key = self.env['ir.config_parameter'].sudo().get_param('evolution.api_key')
        instance = self.env['ir.config_parameter'].sudo().get_param('evolution.instance_name')
        
        if not base_url or not api_key or not instance:
            return self._show_notification(
                _("Error"),
                _("Faltan credenciales (URL, API Key o Instancia)"),
                'danger'
            )
            
        is_apichat_io = 'apichat.io' in (base_url or '')

        if is_apichat_io:
             # APIChat.io Test
             # We can test /instance/connectionState/{instance} OR ensure headers
             url = f"{base_url.rstrip('/')}/instance/connectionState/{instance}"
             headers = {
                 "client-id": instance,
                 "token": api_key,
                 "Content-Type": "application/json",
             }
        else:
             # Evolution API Standard
             headers = {
                 "apikey": api_key,
                 "Content-Type": "application/json",
             }
             url = f"{base_url.rstrip('/')}/instance/connectionState/{instance}"
        
        try:
            resp = requests.get(url, headers=headers, timeout=20)
            
            if resp.ok:
                try:
                    data = resp.json()
                except Exception:
                    msg = _("⚠️ Error: La URL configurada devuelve HTML en lugar de JSON.\n\nEs probable que hayas puesto la URL del panel (Manager) en lugar de la API.\nPrueba usar solo la raíz: %s") % base_url.split('/manager')[0]
                    return self._show_notification(_("URL Incorrecta"), msg, 'danger')
                    
                # Evolution devuelve algo como: {"instance": "...", "state": "open"}
                state = data.get('state', 'unknown') if isinstance(data, dict) else 'ok'
                
                if state == 'open':
                    msg = _("✅ Conectado y Listo (State: open)")
                    return self._show_notification(_("Test Conexión"), msg, 'success')
                else:
                    msg = _("⚠️ Conexión HTTP OK, pero estado de instancia: %s") % state
                    return self._show_notification(_("Test Conexión"), msg, 'warning')
            else:
                msg = _("❌ Error HTTP %s\n\n%s") % (resp.status_code, resp.text[:200])
                if is_apichat_io and resp.status_code == 401:
                     msg += _("\n\n(Asegúrate de que 'Nombre de Instancia' sea tu Client ID y 'API Key' sea tu Token)")
                return self._show_notification(_("Test Conexión"), msg, 'danger')
                
        except Exception as e:
             return self._show_notification(_("Test Conexión"), str(e), 'danger')

    def action_test_apichat_webhook(self):
        """Prueba la conexión con el webhook configurado."""
        self.ensure_one()
        self.set_values() # Guardamos primero
        
        url = self.env['ir.config_parameter'].sudo().get_param('apichat.webhook_url', '').strip()
        
        if not url:
            return self._show_notification(
                _("Error"),
                _("No hay URL de webhook configurada"),
                'danger'
            )
        
        timeout = int(self.env['ir.config_parameter'].sudo().get_param('apichat.webhook_timeout', 20))
        verify_ssl = bool(self.env['ir.config_parameter'].sudo().get_param('apichat.webhook_verify_ssl', True))
        
        # Payload de prueba
        payload = {
            "test": True,
            "source": "odoo_apichat",
            "message": "Test de conexión desde Odoo",
            "timestamp": fields.Datetime.now().isoformat(),
        }
        
        _logger.info("Probando webhook: %s (timeout=%s, verify_ssl=%s)", url, timeout, verify_ssl)
        
        try:
            resp = requests.post(
                url,
                json=payload,
                timeout=timeout,
                verify=verify_ssl,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "Odoo-APIChat/19.0"
                },
            )
            
            if resp.ok:
                message = _("✅ Webhook respondió correctamente\n\nCódigo: %s") % resp.status_code
                notification_type = 'success'
            else:
                message = _("⚠️ Webhook respondió con error\n\nCódigo: %s") % resp.status_code
                notification_type = 'warning'
                
        except Exception as e:
            message = _("❌ Error: %s") % str(e)
            notification_type = 'danger'
        
        return self._show_notification(_("Prueba de Webhook"), message, notification_type)

    def _show_notification(self, title, message, notification_type='info'):
        """Helper para mostrar notificaciones."""
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': title,
                'message': message,
                'type': notification_type,
                'sticky': notification_type == 'danger',
            }
        }

    def action_sync_apichat_groups(self):
        """Sincroniza los grupos disponibles desde Evolution API."""
        self.ensure_one()
        self.set_values()
        
        base_url = self.env['ir.config_parameter'].sudo().get_param('evolution.api_url')
        api_key = self.env['ir.config_parameter'].sudo().get_param('evolution.api_key')
        instance = self.env['ir.config_parameter'].sudo().get_param('evolution.instance_name')
        
        if not base_url or not api_key or not instance:
            return self._show_notification(
                _("Error"),
                _("Faltan credenciales configuradas"),
                'danger'
            )
        
        headers = {
            "apikey": api_key,
            "Content-Type": "application/json",
        }
        
        # Limpiar URL por si el usuario puso slash al final
        base_url = (base_url or "").rstrip('/')
        
        # Endpoint: /group/fetchAllGroups/{instance}
        # Parametros opcionales: getParticipants=true
        url = f"{base_url}/group/fetchAllGroups/{instance}?getParticipants=true"
        
        _logger.info("🚀 Iniciando sincronización de grupos Evolution API: %s", url)
        
        try:
            resp = requests.get(url, headers=headers, timeout=60)
            
            _logger.info("📡 Respuesta Evolution Groups: HTTP %s | Content-Length: %s", resp.status_code, len(resp.content))
            
            if not resp.ok:
                msg = _("❌ Error al obtener grupos: %s") % resp.text[:200]
                return self._show_notification(_("Error Sync"), msg, 'danger')
            
            try:
                groups_data = resp.json()
            except Exception as e:
                _logger.error("❌ Error de JSON. Contenido recibido: %s", resp.text[:500])
                msg = _("El servidor respondió con OK pero envio datos inválidos:\n%s") % resp.text[:200]
                return self._show_notification(_("Error de Datos"), msg, 'warning')
            if not groups_data:
                return self._show_notification(_("Sync Grupos"), _("No se encontraron grupos."), 'warning')
                
            # Evolution retorna una lista directa [ {}, {} ]
            if not isinstance(groups_data, list):
                # A veces puede venir envuelto, revisar
                _logger.warning("Formato inesperado: %s", type(groups_data))
                if isinstance(groups_data, dict):
                    groups_data = groups_data.get('data', []) or []
            
            count_new = 0
            count_updated = 0
            
            ApiChatGroup = self.env['apichat.group'].sudo()
            
            for g in groups_data:
                # Mapeo Evolution API
                group_id = g.get('id')
                subject = g.get('subject', 'Sin Nombre')
                
                if not group_id:
                    continue
                    
                # Calcular participantes
                participants = g.get('participants', [])
                p_count = len(participants) if isinstance(participants, list) else 0
                
                vals = {
                    'name': subject,
                    'group_id': group_id,
                    'participant_count': p_count,
                    'last_sync': fields.Datetime.now(),
                }
                
                existing = ApiChatGroup.search([('group_id', '=', group_id)], limit=1)
                
                if existing:
                    existing.write(vals)
                    count_updated += 1
                else:
                    ApiChatGroup.create(vals)
                    count_new += 1
            
            msg = _("Sincronización completada.\n\nNuevos: %s\nActualizados: %s") % (count_new, count_updated)
            return self._show_notification(_("Sync Exitoso"), msg, 'success')
            
        except Exception as e:
            _logger.exception("Error sync grupos evolution")
            return self._show_notification(_("Error Fatal"), str(e), 'danger')

    # Eliminar métodos auxiliares viejos si ya no se usan, o dejarlos como legacy
    # _process_dialog_batch se elimina con el remplazo anterior si cubría todo,
    # pero aquí estoy reemplazando desde la linea 202 hasta el final (381).