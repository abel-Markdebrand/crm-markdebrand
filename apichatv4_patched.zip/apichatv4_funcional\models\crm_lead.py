# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class CrmLead(models.Model):
    _inherit = "crm.lead"

    # Campos para mensajería por grupos de WhatsApp
    use_group_chat = fields.Boolean(
        string="Usar Chat de Grupo",
        default=False,
        help="Enviar/recibir mensajes de este lead a través de un grupo de WhatsApp"
    )
    apichat_group_id = fields.Many2one(
        'apichat.group',
        string="Grupo de WhatsApp",
        domain=[('active', '=', True)],
        help="Grupo de WhatsApp asociado a este lead"
    )

    @api.onchange('use_group_chat')
    def _onchange_use_group_chat(self):
        """Limpiar grupo si se desactiva la opción."""
        if not self.use_group_chat:
            self.apichat_group_id = False

    def action_send_whatsapp(self):
        """
        Abre wizard para enviar WhatsApp al lead.
        """
        self.ensure_one()
        
        # Si usa grupo, no es necesario tener teléfono
        if not self.use_group_chat and not self.phone:
            raise UserError(_("Este lead no tiene número de teléfono"))
        
        if self.use_group_chat and not self.apichat_group_id:
            raise UserError(_("Este lead tiene activado 'Usar Chat de Grupo' pero no tiene grupo asignado"))
        
        context = {
            'default_lead_id': self.id,
        }
        
        if self.use_group_chat and self.apichat_group_id:
            context['default_use_group'] = True
            context['default_group_id'] = self.apichat_group_id.id
        else:
            context['default_number'] = self.phone
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Enviar WhatsApp a %s') % self.name,
            'res_model': 'send.whatsapp.crm.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': context
        }

    @api.model
    def _find_or_create_lead_by_phone(self, phone):
        """
        Busca o crea un lead basado en el número de teléfono.
        """
        if not phone:
            raise UserError(_("No se proporcionó número de teléfono"))
        
        # Normalizar número
        phone_clean = phone.strip().replace(" ", "").replace("-", "")
        
        # Buscar lead existente
        lead = self.search([('phone', 'ilike', phone_clean)], limit=1)
        
        if lead:
            _logger.info("Lead encontrado: %s (id %s)", lead.name, lead.id)
            return lead
        
        # Crear nuevo lead
        lead = self.create({
            'name': _("WhatsApp: %s") % phone_clean,
            'phone': phone_clean,
            'type': 'opportunity',
            'description': _("Lead creado desde WhatsApp"),
        })
        
        _logger.info("Nuevo lead creado: %s (id %s)", lead.name, lead.id)
        return lead

    @api.model
    def find_lead_by_group_id(self, group_id):
        """
        Busca un lead que tenga asignado el grupo de WhatsApp especificado.
        
        Args:
            group_id: ID del grupo de APIChat (ej: 120363XXXXX@g.us)
            
        Returns:
            crm.lead record o None si no se encuentra
        """
        if not group_id:
            return None
        
        # Buscar el grupo en nuestra tabla
        apichat_group = self.env['apichat.group'].sudo().search([
            ('group_id', '=', group_id),
            ('active', '=', True)
        ], limit=1)
        
        if not apichat_group:
            _logger.debug("Grupo %s no encontrado en apichat.group", group_id)
            return None
        
        # Buscar lead que use este grupo
        lead = self.sudo().search([
            ('use_group_chat', '=', True),
            ('apichat_group_id', '=', apichat_group.id),
            ('active', '=', True)
        ], order='write_date desc', limit=1)
        
        if lead:
            _logger.info("🔗 Lead encontrado por grupo %s: %s (id %s)", group_id, lead.name, lead.id)
        else:
            _logger.debug("No hay lead con grupo %s asignado", group_id)
        
        return lead

    @api.model
    def find_leads_by_group_id(self, group_id):
        """
        Busca TODOS los leads que tengan asignado el grupo de WhatsApp especificado.
        
        Args:
            group_id: ID del grupo de APIChat (ej: 120363XXXXX@g.us)
            
        Returns:
            crm.lead recordset
        """
        if not group_id:
            return self.env['crm.lead']
        
        # Buscar el grupo en nuestra tabla
        apichat_group = self.env['apichat.group'].sudo().search([
            ('group_id', '=', group_id),
            ('active', '=', True)
        ], limit=1)
        
        if not apichat_group:
            _logger.debug("Grupo %s no encontrado en apichat.group", group_id)
            return self.env['crm.lead']
        
        # Buscar leads que usen este grupo
        leads = self.sudo().search([
            ('use_group_chat', '=', True),
            ('apichat_group_id', '=', apichat_group.id),
            ('active', '=', True)
        ], order='write_date desc')
        
        if leads:
            _logger.info("🔗 Leads encontrados por grupo %s: %s (ids %s)", group_id, len(leads), leads.ids)
        else:
            _logger.debug("No hay leads con grupo %s asignado", group_id)
        
        return leads