# -*- coding: utf-8 -*-
from odoo import models, _


class HrApplicant(models.Model):
    _inherit = "hr.applicant"

    def action_send_whatsapp(self):
        """Abre el wizard de envío de WhatsApp."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Enviar WhatsApp"),
            "res_model": "send.whatsapp.crm.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_applicant_id": self.id,
                "default_number": self.partner_phone or "",
            },
        }