from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError
import json

class TestApiChat(TransactionCase):

    def setUp(self):
        super(TestApiChat, self).setUp()
        self.RawMessage = self.env['apichat.raw.message']
        self.Partner = self.env['res.partner']
        self.Lead = self.env['crm.lead']
        
        # Crear un partner de prueba
        self.partner = self.Partner.create({
            'name': 'Test Partner',
            'phone': '584245455079',
        })
        
    def test_phone_normalization(self):
        """Probar la normalización de números (usando método interno _digits)"""
        # Accedemos a la función _digits definida en el módulo (necesitamos importarla o usar el método del modelo si se expone)
        # Como es una función helper no expuesta, probaremos indirectamente a través del parsing
        
        raw_data = json.dumps({
            "author": "58424-545-5079",
            "text": "Hello"
        })
        msg = self.RawMessage.create({'raw_data': raw_data})
        self.assertEqual(msg.phone_number, "584245455079", "El número debería estar limpio en el campo calculado")

    def test_webhook_parsing(self):
        """Probar el parsing del payload del webhook"""
        payload = {
            "messages": [
                {
                    "author": "584245455079",
                    "text": "Test Message",
                    "type": "text",
                    "time": 1678886400,
                    "from_me": False
                }
            ]
        }
        
        # Ejecutar procesamiento
        processed_count = self.RawMessage.process_webhook_payload(payload)
        
        # Debería haber procesado 1 mensaje
        self.assertEqual(processed_count, 1)
        
        # Verificar que se publicó en el chatter del partner
        messages = self.partner.message_ids
        self.assertTrue(any("Test Message" in m.body for m in messages), "El mensaje debería aparecer en el chatter del partner")

    def test_ignore_groups_and_outbound(self):
        """Probar que se ignoran mensajes de grupos y salientes"""
        payload = {
            "messages": [
                {
                    "author": "584245455079",
                    "text": "Outbound",
                    "from_me": True
                },
                {
                    "author": "584245455079",
                    "text": "Group Msg",
                    "chat_type": "group"
                }
            ]
        }
        processed_count = self.RawMessage.process_webhook_payload(payload)
        self.assertEqual(processed_count, 0, "No debería procesar mensajes salientes ni de grupos")

    def test_find_lead(self):
        """Probar que encuentra el lead asociado al partner"""
        lead = self.Lead.create({
            'name': 'Test Lead',
            'partner_id': self.partner.id,
            'type': 'opportunity'
        })
        
        payload = {
            "messages": [
                {
                    "author": "584245455079",
                    "text": "Lead Message",
                    "type": "text"
                }
            ]
        }
        
        self.RawMessage.process_webhook_payload(payload)
        
        # Verificar mensaje en el lead
        messages = lead.message_ids
        self.assertTrue(any("Lead Message" in m.body for m in messages), "El mensaje debería aparecer en el chatter del lead")

    def test_media_message_parsing_image(self):
        """Probar el parsing de mensajes con imágenes"""
        payload = {
            "messages": [
                {
                    "author": "584245455079",
                    "type": "image",
                    "url": "https://example.com/test.jpg",
                    "mime_type": "image/jpeg",
                    "caption": "Foto de prueba",
                    "time": 1678886400,
                    "from_me": False
                }
            ]
        }
        
        # El procesamiento debería detectar el tipo de media
        processed_count = self.RawMessage.process_webhook_payload(payload)
        self.assertEqual(processed_count, 1, "Debería procesar el mensaje de imagen")
        
        # Verificar que el caption aparece en el chatter
        messages = self.partner.message_ids
        self.assertTrue(
            any("Foto de prueba" in (m.body or "") or "image" in (m.body or "").lower() for m in messages),
            "El mensaje de imagen debería aparecer en el chatter"
        )

    def test_media_message_parsing_document(self):
        """Probar el parsing de mensajes con documentos"""
        payload = {
            "messages": [
                {
                    "author": "584245455079",
                    "type": "document",
                    "url": "https://example.com/test.pdf",
                    "mime_type": "application/pdf",
                    "filename": "documento.pdf",
                    "time": 1678886400,
                    "from_me": False
                }
            ]
        }
        
        processed_count = self.RawMessage.process_webhook_payload(payload)
        self.assertEqual(processed_count, 1, "Debería procesar el mensaje de documento")
