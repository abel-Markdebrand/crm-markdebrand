# -*- coding: utf-8 -*-

# URL base de la API de APIChat
API_BASE = "https://api.apichat.io"