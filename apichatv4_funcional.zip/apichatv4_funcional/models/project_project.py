# -*- coding: utf-8 -*-
from odoo import models, fields, _
from odoo.exceptions import UserError


class ProjectProject(models.Model):
    _inherit = "project.project"

    # Campo para vincular el proyecto con un cliente
    partner_id = fields.Many2one(
        'res.partner',
        string='Cliente',
        help='Cliente o contacto asociado a este proyecto',
        tracking=True,
    )

    def action_send_whatsapp(self):
        """
        Abre el wizard para enviar WhatsApp al cliente del proyecto.
        """
        self.ensure_one()
        
        # Verificar que el proyecto tenga un cliente (partner)
        if not self.partner_id:
            raise UserError(_("Este proyecto no tiene un cliente asignado.\n\nPor favor, selecciona un cliente en el campo 'Cliente' del proyecto."))
        
        # Verificar que el cliente tenga número de teléfono
        if not self.partner_id.phone:
            raise UserError(_("El cliente '%s' no tiene número de teléfono") % self.partner_id.name)
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Enviar WhatsApp a %s') % self.partner_id.name,
            'res_model': 'send.whatsapp.crm.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_number': self.partner_id.phone,
                'default_partner_id': self.partner_id.id,
                'default_project_id': self.id,
            }
        }
