# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api, _

_logger = logging.getLogger(__name__)


class ApiChatGroup(models.Model):
    _name = "apichat.group"
    _description = "Grupos de WhatsApp de APIChat"
    _order = "name"
    _rec_name = "name"

    name = fields.Char(
        string="Nombre del Grupo",
        required=True,
        help="Nombre del grupo de WhatsApp"
    )
    group_id = fields.Char(
        string="ID del Grupo",
        required=True,
        index=True,
        help="Identificador único del grupo en APIChat (ej: 120363XXXXX@g.us)"
    )
    description = fields.Text(
        string="Descripción",
        help="Descripción o notas sobre este grupo"
    )
    active = fields.Boolean(
        default=True,
        help="Desactivar para ocultar el grupo sin eliminarlo"
    )
    participant_count = fields.Integer(
        string="Participantes",
        help="Número de participantes en el grupo"
    )
    last_sync = fields.Datetime(
        string="Última Sincronización",
        readonly=True,
        help="Fecha de última sincronización desde APIChat"
    )
    
    # Relación inversa para ver qué leads usan este grupo
    lead_ids = fields.One2many(
        'crm.lead',
        'apichat_group_id',
        string="Leads Asociados"
    )
    lead_count = fields.Integer(
        string="Leads",
        compute="_compute_lead_count"
    )

    _sql_constraints = [
        ('group_id_unique', 'unique(group_id)', 'El ID del grupo debe ser único.')
    ]

    @api.depends('lead_ids')
    def _compute_lead_count(self):
        for rec in self:
            rec.lead_count = len(rec.lead_ids)

    def name_get(self):
        """Mostrar nombre con cantidad de participantes si existe."""
        result = []
        for rec in self:
            name = rec.name
            if rec.participant_count:
                name = f"{rec.name} ({rec.participant_count} participantes)"
            result.append((rec.id, name))
        return result
