# -*- coding: utf-8 -*-
from odoo import models, api, _
from odoo.exceptions import UserError
import re

def _norm(num):
    return re.sub(r"\D+", "", num or "")

class SendWhatsappCRMDiscuss(models.TransientModel):
    _inherit = "send.whatsapp.crm.wizard"

    def _get_or_create_wa_channel(self, number, lead=None):
        """Crea o recupera un canal de Discuss por número."""
        Channel = self.env["mail.channel"].sudo()
        chan_name = f"WhatsApp {number}"
        channel = Channel.search([("name", "=", chan_name), ("channel_type", "=", "chat")], limit=1)
        if not channel:
            channel = Channel.create({"name": chan_name, "channel_type": "chat"})
            # Añade admin y (si existe) el usuario asignado del lead
            admin = self.env.ref("base.user_admin", raise_if_not_found=False)
            user_ids = [u.id for u in filter(None, [admin])]
            if lead and lead.user_id:
                user_ids.append(lead.user_id.id)
            if user_ids:
                partners = self.env["res.users"].sudo().browse(user_ids).mapped("partner_id")
                channel.write({"channel_partner_ids": [(4, p.id) for p in partners]})
        return channel

    def _mirror_to_discuss(self):
        """Refleja el mensaje saliente en Discuss (no reenvía por API)."""
        self.ensure_one()
        # Estos campos ya existen en tu wizard
        number = _norm(getattr(self, "number", "") or "")
        if not number:
            return
        lead = getattr(self, "lead_id", False)
        channel = self._get_or_create_wa_channel(number, lead=lead)

        # Detecta tipo segun campos opcionales que agregaste (si los tienes)
        tipo = None
        if hasattr(self, "video_url") and self.video_url:
            tipo = "video"
            body = f"📤 (video) {self.message or ''}<br/><a href='{self.video_url}' target='_blank'>{self.video_url}</a>"
        elif hasattr(self, "image_url") and self.image_url:
            tipo = "imagen"
            body = f"📤 (imagen) {self.message or ''}<br/><a href='{self.image_url}' target='_blank'>{self.image_url}</a>"
        elif hasattr(self, "audio_url") and self.audio_url:
            tipo = "audio"
            body = f"📤 (audio) {self.message or ''}<br/><a href='{self.audio_url}' target='_blank'>{self.audio_url}</a>"
        else:
            tipo = "texto"
            body = f"📤 {self.message or ''}"

        # Postea al canal de Discuss
        channel.message_post(body=body, subtype_xmlid="mail.mt_comment")

    def action_send(self):
        """Llama a tu envío actual y luego refleja el mensaje en Discuss."""
        self.ensure_one()
        res = super().action_send()  # no tocamos tu lógica de envío ni validación
        # Si el envío fue exitoso (no lanzó UserError), espejamos en Discuss:
        try:
            self._mirror_to_discuss()
        except Exception:
            # Nunca romper el flujo por un fallo visual en Discuss
            pass
        return res
