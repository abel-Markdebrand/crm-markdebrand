import logging
import requests
import time
from markupsafe import Markup
from odoo import models, fields, api, _
from odoo.tools import html_escape as escape
from odoo.exceptions import UserError, ValidationError
from ..models.utils import normalize_phone, is_send_ok

_logger = logging.getLogger(__name__)


class SendWhatsappMassWizard(models.TransientModel):
    _name = "send.whatsapp.mass.wizard"
    _description = "Wizard para envío masivo de WhatsApp"

    # Origen
    lead_ids = fields.Many2many("crm.lead", string="Oportunidades/Leads")
    applicant_ids = fields.Many2many("hr.applicant", string="Candidatos")
    partner_ids = fields.Many2many("res.partner", string="Contactos")
    
    # Mensaje
    message = fields.Text(string="Mensaje", required=True)
    
    # Opciones
    log_in_chatter = fields.Boolean(
        string="Registrar en Chatter",
        default=True,
        help="Agregar el mensaje enviado al historial de cada registro"
    )
    delay_seconds = fields.Float(
        string="Delay entre envíos (seg)",
        default=0.5,
        help="Tiempo de espera entre cada envío para evitar rate limiting (ej: 0.5 = 2 msg/seg)"
    )
    
    # Estadísticas (computed)
    total_leads = fields.Integer(string="Total Registros", compute="_compute_stats")
    leads_with_phone = fields.Integer(string="Con Teléfono", compute="_compute_stats")
    leads_without_phone = fields.Integer(string="Sin Teléfono", compute="_compute_stats")

    @api.depends('lead_ids', 'applicant_ids', 'partner_ids')
    def _compute_stats(self):
        """Calcula estadísticas de los registros seleccionados."""
        for rec in self:
            records = rec._get_records()
            rec.total_leads = len(records)
            
            count = 0
            for r in records:
                phone = rec._get_phone(r)
                if phone: count += 1
            
            rec.leads_with_phone = count
            rec.leads_without_phone = rec.total_leads - count

    def _get_records(self):
        """Devuelve los registros afectados según lo seleccionado."""
        if self.lead_ids: return self.lead_ids
        if self.applicant_ids: return self.applicant_ids
        if self.partner_ids: return self.partner_ids
        return []

    def _get_phone(self, record):
        """Obtiene el teléfono según el modelo del registro."""
        if record._name == 'crm.lead':
            return getattr(record, 'phone', False) or getattr(record, 'mobile', False)
        
        elif record._name == 'hr.applicant':
            return getattr(record, 'partner_phone', False) or getattr(record, 'partner_mobile', False)
        
        elif record._name == 'res.partner':
            return getattr(record, 'phone', False) or getattr(record, 'mobile', False)
            
        return False

    @api.model
    def default_get(self, fields_list):
        """Prellenar el wizard con los registros seleccionados."""
        res = super().default_get(fields_list)
        
        active_ids = self._context.get("active_ids", [])
        active_model = self._context.get("active_model")
        
        if active_ids:
            if active_model == "crm.lead":
                res["lead_ids"] = [(6, 0, active_ids)]
            elif active_model == "hr.applicant":
                res["applicant_ids"] = [(6, 0, active_ids)]
            elif active_model == "res.partner":
                res["partner_ids"] = [(6, 0, active_ids)]
        
        return res

    @api.constrains('delay_seconds')
    def _check_delay(self):
        """Valida que el delay sea razonable."""
        for rec in self:
            if rec.delay_seconds < 0:
                raise ValidationError(_("El delay no puede ser negativo."))
            if rec.delay_seconds > 60:
                raise ValidationError(_("El delay no puede ser mayor a 60 segundos."))

    def action_send_mass(self):
        """Envía mensajes masivos de WhatsApp usando Evolution API."""
        self.ensure_one()
        
        records = self._get_records()
        
        # 1. Validaciones
        if not records:
            raise UserError(_("Debe seleccionar al menos un registro."))
        
        if not self.message or not self.message.strip():
            raise UserError(_("El mensaje no puede estar vacío."))
        
        # 2. Obtener configuración de Evolution API
        ICP = self.env['ir.config_parameter'].sudo()
        api_base = ICP.get_param('evolution.api_url')
        api_key = ICP.get_param('evolution.api_key')
        instance = ICP.get_param('evolution.instance_name')
        
        if not api_base or not api_key or not instance:
            raise UserError(_("Configure Evolution API primero en Ajustes > APIChat Integration."))
            
        # 3. Filtrar registros con teléfono
        records_to_process = []
        records_without_phone = []
        
        for r in records:
            phone = self._get_phone(r)
            if phone and normalize_phone(phone):
                records_to_process.append(r)
            else:
                records_without_phone.append(r)
        
        if not records_to_process:
            raise UserError(_("Ninguno de los registros seleccionados tiene número de teléfono válido."))
        
        # 4. Confirmar envío si hay muchos
        if len(records_to_process) > 50:
            _logger.warning("Enviando a %s registros (esto puede tardar)", len(records_to_process))
        
        # 5. Procesar envíos con Evolution API
        results = {
            'success': 0,
            'failed': 0,
            'skipped': len(records_without_phone),
            'errors': []
        }
        
        url = f"{api_base.rstrip('/')}/message/sendText/{instance}"
        headers = {
            'apikey': api_key,
            'Content-Type': 'application/json'
        }
        
        for idx, record in enumerate(records_to_process, 1):
            name = getattr(record, 'name', 'Registro')
            partner = getattr(record, 'partner_id', None)
            if record._name == 'res.partner':
                partner = record
            
            try:
                # Obtener y normalizar número
                phone = self._get_phone(record)
                number = normalize_phone(phone)
                
                if not number or len(number) < 8 or len(number) > 15:
                    _logger.warning("Registro %s tiene número inválido: %s", record.id, phone)
                    results['failed'] += 1
                    results['errors'].append(f"{name}: Número inválido")
                    continue
                
                # Preparar destino con formato WhatsApp
                destination = f"{number}@s.whatsapp.net"
                
                # Preparar payload para Evolution API (estructura plana)
                payload = {
                    "number": destination,
                    "text": self.message.strip(),
                    "delay": 1200,
                    "linkPreview": False
                }
                
                # Enviar
                _logger.info("[%s/%s] Enviando a %s (%s)", idx, len(records_to_process), name, number)
                
                resp = requests.post(url, json=payload, headers=headers, timeout=30)
                ok, data = is_send_ok(resp)
                
                if ok:
                    results['success'] += 1
                    # Evolution devuelve key.id
                    message_id = data.get("key", {}).get("id") or data.get("messageId") or "N/A"
                    
                    # Registrar en chatter si está habilitado
                    if self.log_in_chatter:
                        self._log_in_chatter(record, number, message_id)
                    
                    # Tracking: Crear registro
                    try:
                        # Determinar lead id si aplica
                        lead_id = record.id if record._name == 'crm.lead' else None
                        partner_id = partner.id if partner else None
                        
                        self.env['apichat.sent.message'].create_from_send_result(
                            data, 
                            lead=self.env['crm.lead'].browse(lead_id) if lead_id else None, 
                            partner=self.env['res.partner'].browse(partner_id) if partner_id else None,
                            msg_type='text',
                            content=self.message.strip()
                        )
                    except Exception as e:
                        _logger.warning("Error creating tracking for mass message: %s", e)

                    _logger.info("✅ Enviado a %s - MessageID: %s", name, message_id)
                else:
                    results['failed'] += 1
                    error_msg = data.get("error") or data.get("message") or resp.text[:200]
                    results['errors'].append(f"{name}: {error_msg}")
                    _logger.warning("❌ Falló envío a %s: %s", name, error_msg)
                
            except requests.Timeout:
                results['failed'] += 1
                results['errors'].append(f"{name}: Timeout")
                _logger.error("Timeout enviando a %s", name)
                
            except requests.RequestException as e:
                results['failed'] += 1
                error_msg = str(e)[:200]
                results['errors'].append(f"{name}: {error_msg}")
                _logger.exception("Error enviando a %s: %s", name, e)
            
            except Exception as e:
                results['failed'] += 1
                results['errors'].append(f"{name}: Error inesperado")
                _logger.exception("Error crítico enviando a %s: %s", name, e)
            
            # Rate limiting: esperar entre envíos
            if idx < len(records_to_process) and self.delay_seconds > 0:
                time.sleep(self.delay_seconds)
        
        # 6. Mostrar resumen
        return self._show_results(results, records_without_phone)

    def _log_in_chatter(self, record, number, message_id):
        """Registra el envío en el chatter del registro."""
        if not hasattr(record, 'message_post'):
            return
            
        safe_message = escape(self.message)
        
        body_str = _(
            "📤 <strong>WhatsApp Enviado</strong> (ID: %s)<br/>%s"
        ) % (message_id, safe_message)
        
        record.message_post(
            body=Markup(body_str),
            subtype_xmlid='mail.mt_comment',
            message_type='comment'
        )

    def _show_results(self, results, leads_without_phone):
        """Muestra un resumen de los resultados del envío masivo."""
        summary = _(
            "Resumen de Envío Masivo:\n\n"
            "✅ Exitosos: %s\n"
            "❌ Fallidos: %s\n"
            "⚠️ Sin teléfono: %s\n"
        ) % (results['success'], results['failed'], results['skipped'])
        
        # Agregar leads sin teléfono
        if leads_without_phone:
            summary += "\nRegistros sin teléfono:\n"
            for r in leads_without_phone[:10]:  # Máximo 10
                name = getattr(r, 'name', 'Desconocido')
                summary += f"• {name}\n"
            if len(leads_without_phone) > 10:
                summary += f"• ... y {len(leads_without_phone) - 10} más\n"
        
        # Agregar errores
        if results['errors']:
            summary += "\nErrores:\n"
            for error in results['errors'][:10]:  # Máximo 10
                summary += f"• {error}\n"
            if len(results['errors']) > 10:
                summary += f"• ... y {len(results['errors']) - 10} más\n"
        
        # Determinar tipo de notificación
        if results['failed'] == 0 and results['skipped'] == 0:
            notification_type = 'success'
        elif results['success'] == 0:
            notification_type = 'danger'
        else:
            notification_type = 'warning'
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("Envío Masivo Completado"),
                'message': summary,
                'type': notification_type,
                'sticky': True,
            }
        }