import logging
import re
import json
import base64
import requests
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from markupsafe import Markup

_logger = logging.getLogger(__name__)
API_BASE = "https://api.apichat.io"

# Tipos MIME soportados
IMAGE_MIMES = {'image/jpeg', 'image/png', 'image/webp', 'image/gif'}
DOCUMENT_MIMES = {'application/pdf', 'application/msword', 
                  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                  'application/vnd.ms-excel', 'text/plain', 'text/csv'}
AUDIO_MIMES = {'audio/mpeg', 'audio/mp3', 'audio/ogg', 'audio/opus', 'audio/wav', 
               'audio/x-wav', 'audio/aac', 'audio/m4a', 'audio/x-m4a'}
VIDEO_MIMES = {'video/mp4', 'video/3gpp', 'video/quicktime', 'video/webm', 
               'video/x-msvideo', 'video/mpeg'}


def _normalize_phone(p):
    """Normaliza el número de teléfono eliminando caracteres no numéricos."""
    return re.sub(r"\D+", "", p or "")


def _is_send_ok(resp):
    """Acepta como OK si:
       - HTTP 2xx, y
       - JSON contiene success True, o messageId, o status en {sent, delivered, queued}
    """
    if not resp.ok:
        return False, {}
    try:
        data = resp.json()
    except Exception:
        return False, {}
    
    success = bool(data.get("success"))
    message_id = data.get("messageId") or data.get("id") or data.get("message_id")
    # Evolution API devuelve key.id para mensajes exitosos
    if not message_id and isinstance(data.get("key"), dict):
        message_id = data["key"].get("id")
    status = (data.get("status") or "").lower()
    ok = success or message_id or status in {"sent", "delivered", "queued", "pending"}
    return bool(ok), data


def _get_media_type(mimetype):
    """Determina el tipo de media basado en el MIME type para Evolution API."""
    if mimetype in IMAGE_MIMES:
        return 'image'
    elif mimetype in VIDEO_MIMES:
        return 'video'
    elif mimetype in AUDIO_MIMES:
        return 'audio'
    elif mimetype in DOCUMENT_MIMES:
        return 'document'
    # Default para otros tipos
    return 'document'


class SendWhatsappCrmWizard(models.TransientModel):
    _name = "send.whatsapp.crm.wizard"
    _description = "Wizard para enviar WhatsApp desde CRM o Reclutamiento"

    # Origen del envío
    lead_id = fields.Many2one("crm.lead", string="Oportunidad/Lead")
    applicant_id = fields.Many2one("hr.applicant", string="Candidato")
    partner_id = fields.Many2one("res.partner", string="Contacto")
    project_id = fields.Many2one("project.project", string="Proyecto")

    # Datos del mensaje
    number = fields.Char(string="Número de Teléfono")
    message = fields.Text(string="Mensaje")
    
    # Campos para envío a grupos
    use_group = fields.Boolean(
        string="Enviar a Grupo",
        default=False,
        help="Enviar mensaje al grupo de WhatsApp en lugar del número directo"
    )
    group_id = fields.Many2one(
        'apichat.group',
        string="Grupo de WhatsApp",
        domain=[('active', '=', True)]
    )
    
    # Campos para adjuntos
    attachment_ids = fields.Many2many(
        'ir.attachment', 
        string="Adjuntos",
        help="Imágenes (JPG, PNG, WEBP, GIF), Videos (MP4, 3GP), Audio (MP3, OGG, WAV) o Documentos (PDF, DOCX, XLSX)"
    )

    # Opciones
    log_in_chatter = fields.Boolean(
        string="Registrar en Chatter",
        default=True,
        help="Agregar el mensaje enviado al historial del registro"
    )

    @api.model
    def default_get(self, fields_list):
        """Prellenar el wizard con datos del contexto."""
        res = super().default_get(fields_list)
        
        # Desde CRM Lead
        if self.env.context.get("active_model") == "crm.lead":
            lead_id = self.env.context.get("active_id")
            if lead_id:
                lead = self.env["crm.lead"].browse(lead_id)
                res["lead_id"] = lead_id
                lead_phone = getattr(lead, 'phone', False) or getattr(lead, 'mobile', False) or ""
                res["number"] = _normalize_phone(lead_phone)
                
                # Prellenar grupo si está configurado en el lead
                if lead.use_group_chat and lead.apichat_group_id:
                    res['use_group'] = True
                    res['group_id'] = lead.apichat_group_id.id
                
        # Desde HR Applicant
        elif self.env.context.get("active_model") == "hr.applicant":
            applicant_id = self.env.context.get("active_id")
            if applicant_id:
                applicant = self.env["hr.applicant"].browse(applicant_id)
                res["applicant_id"] = applicant_id
                res["number"] = _normalize_phone(applicant.partner_phone or "")
                
        # Desde Contactos (res.partner)
        elif self.env.context.get("active_model") == "res.partner":
            partner_id = self.env.context.get("active_id")
            if partner_id:
                partner = self.env["res.partner"].browse(partner_id)
                res["partner_id"] = partner_id
                res["number"] = _normalize_phone(partner.phone or "")
        
        # Desde Proyectos (project.project)
        elif self._context.get("active_model") == "project.project":
            project_id = self._context.get("active_id")
            if project_id:
                project = self.env["project.project"].browse(project_id)
                res["project_id"] = project_id
                if project.partner_id:
                    res["partner_id"] = project.partner_id.id
                    res["number"] = _normalize_phone(project.partner_id.phone or "")
        
        return res

    def action_send(self):
        """Envía el mensaje de WhatsApp con soporte para texto, media y grupos."""
        self.ensure_one()
        
        # 1. Obtener configuración
        ICP = self.env['ir.config_parameter'].sudo()
        base_url = ICP.get_param('evolution.api_url')
        api_key = ICP.get_param('evolution.api_key')
        instance = ICP.get_param('evolution.instance_name')
        
        if not base_url or not api_key or not instance:
            raise UserError(_("No hay credenciales configuradas.\n\nVe a: Ajustes > APIChat Integration"))
        
        # 2. Determinar destino: grupo o número directo
        target_type = 'group' if self.use_group and self.group_id else 'number'
        
        if target_type == 'group':
            target_id = self.group_id.group_id  # ID del grupo en APIChat
            if not target_id:
                raise UserError(_("El grupo seleccionado no tiene ID válido"))
            number = target_id # Para propósitos de log
        else:
            # Normalizar y validar número
            number = _normalize_phone(self.number)
            if not number or len(number) < 8:
                raise UserError(_("Use formato E.164 sin símbolos, p.ej.: 584245455079"))
            target_id = number
        
        # 3. Preparar headers
        headers = {
            'apikey': api_key,
            'Content-Type': 'application/json'
        }
        
        # URL Base Dinámica
        api_base = f"{base_url.rstrip('/')}"
        
        results = []
        
        # 4. Enviar adjuntos si existen
        message_sent_as_caption = False
        if self.attachment_ids:
            for i, attachment in enumerate(self.attachment_ids):
                # Solo poner caption en el primer adjunto para no spammear, o en todos si se prefiere
                # Aquí ponemos caption solo en el último para que quede al final, o en todos.
                # El comportamiento actual era en todos. Mantengámoslo pero marquemos que ya se envió.
                # Solo poner caption en el primer adjunto para no spammear, o en todos si se prefiere
                # Aquí ponemos caption solo en el último para que quede al final, o en todos.
                # El comportamiento actual era en todos. Mantengámoslo pero marquemos que ya se envió.
                media_result = self._send_media_attachment(target_id, attachment, headers, api_base, instance, is_group=(target_type == 'group'))
                results.append(media_result)
                if media_result.get('ok') and self.message:
                    message_sent_as_caption = True
        
        # 5. Enviar texto si existe Y no se ha enviado ya como caption de una imagen exitosa
        # (Si falló el envío de imagen, sí intentamos mandar el texto)
        # 5. Enviar texto si existe Y no se ha enviado ya como caption de una imagen exitosa
        # (Si falló el envío de imagen, sí intentamos mandar el texto)
        if self.message and self.message.strip() and not message_sent_as_caption:
            text_result = self._send_text_message(target_id, headers, api_base, instance, is_group=(target_type == 'group'))
            results.append(text_result)
        
        # 6. Verificar que se envió algo
        if not results:
            raise UserError(_("Debe incluir un mensaje de texto o al menos un adjunto."))
        
        # 7. Verificar resultados
        failed = [r for r in results if not r['ok']]
        if failed:
            error_msg = _("❌ Algunos envíos fallaron:")
            for f in failed:
                error_msg += f"\n- {f['type']}: {f['error']}"
            self._log_error(error_msg)
            raise UserError(error_msg)
        
        # 8. Éxito - Registrar en chatter y Tracking
        if self.log_in_chatter:
            self._log_success_enhanced(number, results)
            
        # Tracking: Crear registros de tracking
        SentMsg = self.env['apichat.sent.message']
        lead = self.lead_id or (self.env['crm.lead'].browse(self.env.context.get('active_id')) if self.env.context.get('active_model') == 'crm.lead' else None)
        partner = self.partner_id or lead.partner_id if lead else None
        
        for res in results:
            if res.get('ok') and res.get('data'):
                # Determinar contenido
                content = self.message or ""
                if res['type'] != 'text':
                     content = f"[{res['type']}] {res.get('name', '')} - {content}"
                
                try:
                    SentMsg.create_from_send_result(
                        res['data'], 
                        lead=lead, 
                        partner=partner, 
                        msg_type=res['type'],
                        content=content
                    )
                except Exception as e:
                    _logger.warning("Error creating tracking record: %s", e)
        
        # 9. Notificar éxito
        msg_count = len([r for r in results if r['type'] == 'text'])
        media_count = len([r for r in results if r['type'] in ('image', 'document')])
        
        destination = target_id
        if self.use_group and self.group_id:
            destination = _("👥 Grupo: %s") % self.group_id.name
        
        notification_msg = _("WhatsApp enviado a %s") % destination
        if msg_count:
            notification_msg += _("\n📝 %s mensaje(s) de texto") % msg_count
        if media_count:
            notification_msg += _("\n📎 %s archivo(s)") % media_count
        
        return {
            'type': 'ir.actions.act_window_close',
            'effect': {
                'fadeout': 'slow',
                'message': _("✅ Mensaje Enviado"),
                'type': 'rainbow_man',
            }
        }

    def _send_text_message(self, target_id, headers, api_base, instance, is_group=False):
        """Envía un mensaje de texto a número o grupo usando endpoint sendMessage de Evolution."""
        if not is_group and self.partner_id:
            ok, data = self.partner_id._send_whatsapp_message(self.message)
            return {'ok': ok, 'type': 'text', 'data': data if ok else {}, 'error': data if not ok else None}
            
        url = f"{api_base}/message/sendText/{instance}"
        destination = target_id
        if not is_group and "@" not in destination:
            destination = f"{destination}@s.whatsapp.net"
            
        payload = {
            "number": destination,
            "text": self.message,
            "delay": 1200,
            "linkPreview": False
        }
        
        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=30)
            if resp.ok:
                data = resp.json()
                msg_id = data.get('key', {}).get('id')
                if msg_id:
                     return {'ok': True, 'type': 'text', 'data': data}
                return {'ok': True, 'type': 'text', 'data': data}
            else:
                return {'ok': False, 'type': 'text', 'error': resp.text[:200]}
        except requests.RequestException as e:
            return {'ok': False, 'type': 'text', 'error': str(e)}

    def _send_media_attachment(self, target_id, attachment, headers, api_base, instance, is_group=False):
        """Envía un archivo adjunto usando endpoint sendMedia de Evolution."""
        if not is_group and self.partner_id:
             ok, data = self.partner_id._send_whatsapp_media(attachment, caption=self.message)
             return {'ok': ok, 'type': 'image', 'data': data if ok else {}, 'error': data if not ok else None, 'name': attachment.name}

        mimetype = attachment.mimetype or 'application/octet-stream'
        media_type = _get_media_type(mimetype)
        evo_media_type = media_type
        if media_type == 'unknown':
            evo_media_type = 'document'
        
        public_url = self._get_attachment_public_url(attachment)
        destination = target_id
        if not is_group and "@" not in destination:
            destination = f"{destination}@s.whatsapp.net"
            
        try:
            url = f"{api_base}/message/sendMedia/{instance}"
            payload = {
                "number": destination,
                "mediatype": evo_media_type,
                "caption": self.message or "",
                "media": public_url,
                "fileName": attachment.name,
                "delay": 1200
            }
            resp = requests.post(url, headers=headers, json=payload, timeout=60)
            if resp.ok:
                 data = resp.json()
                 if data.get('key', {}).get('id'):
                     return {'ok': True, 'type': media_type, 'data': data, 'name': attachment.name}
                 return {'ok': False, 'type': media_type, 'error': str(data)}
            else:
                 return {'ok': False, 'type': media_type, 'error': resp.text[:200]}
        except requests.RequestException as e:
            return {'ok': False, 'type': media_type, 'error': str(e)}


    def _send_reaction(self, target_id, reaction_emoji, message_id_to_react, headers, api_base, instance):
        """Envía una reacción a un mensaje específico."""
        url = f"{api_base}/message/sendReaction/{instance}"
        
        payload = {
            "key": {
                "remoteJid": target_id, # "12345@s.whatsapp.net"
                "fromMe": True, # Asumimos true si reaccionamos a algo propio, pero si es recibido debe ser false? 
                                # Evolution docs dicen: key is the message key being reacted TO.
                "id": message_id_to_react
            },
            "reaction": reaction_emoji
        }
        
        # Ajuste para mensajes recibidos (fromMe=False)
        # Si no tenemos el contexto, intentamos por defecto.
        # TODO: Mejorar lógica de reactions para soportar mensajes entrantes
        
        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=30)
            ok, data = _is_send_ok(resp)
            return {'ok': ok, 'type': 'reaction', 'data': data if ok else {}, 'error': data.get('error') if not ok else None}
        except Exception as e:
            return {'ok': False, 'type': 'reaction', 'error': str(e)}

    def _get_attachment_public_url(self, attachment):
        """Genera URL pública para un attachment usando el controlador dedicado."""
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        
        attachment_sudo = attachment.sudo()
        
        # Generar access_token si no existe o forzar uno nuevo si es necesario
        if not attachment_sudo.access_token:
            attachment_sudo.generate_access_token()
        
        # IMPORTANTE: Hack para hacer visible el token a la request externa de APIChat
        # Como APIChat intentará descargar el archivo INMEDIATAMENTE, necesitamos que
        # el access_token ya esté commiteado en base de datos.
        # De lo contrario, la request entrante de APIChat verá la transacción anterior (sin token)
        # y dará 401 Unauthorized.
        self.env.cr.commit()
        
        # Refrescar para obtener el token actualizado
        attachment_sudo.invalidate_recordset(['access_token'])
        token = attachment_sudo.access_token
        
        # URL usando el controlador público dedicado
        public_url = f"{base_url}/apichat/file/{attachment.id}/{token}"
        
        _logger.info("📎 URL pública generada (commited): %s", public_url)
        return public_url

    def _log_success_enhanced(self, number, results):
        """Registra envío exitoso con detalles de media."""
        parts = []
        
        # Texto del mensaje
        if self.message and self.message.strip():
            safe_message = (self.message or "").replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('\n', '<br/>')
            parts.append(safe_message)
        
        # Archivos enviados
        media_results = [r for r in results if r['type'] in ('image', 'document')]
        if media_results:
            parts.append("<br/><b>📎 Archivos enviados:</b>")
            for r in media_results:
                icon = "🖼️" if r['type'] == 'image' else "📄"
                parts.append(f"<br/>{icon} {r.get('name', 'archivo')}")
        
        body = Markup("".join(parts))
        
        # Publicar en todos los registros relacionados e incluir attachments
        records = [self.lead_id, self.applicant_id, self.partner_id, self.project_id]
        
        # IDs de los attachments enviados para adjuntar al mensaje
        attachment_ids_to_post = self.attachment_ids.ids if self.attachment_ids else []
        
        for record in records:
            if record:
                record.message_post(
                    body=body,
                    message_type='comment',
                    subtype_xmlid='mail.mt_comment',
                    attachment_ids=attachment_ids_to_post  # Adjuntar archivos reales al mensaje
                )

    def _log_error(self, message):
        """Registra error en el chatter del registro correspondiente."""
        if self.lead_id:
            self.lead_id.message_post(
                body=message,
                subtype_xmlid="mail.mt_comment",
            )
        elif self.applicant_id:
            self.applicant_id.message_post(
                body=message,
                subtype_xmlid="mail.mt_comment",
            )
        elif self.partner_id:
            self.partner_id.message_post(
                body=message,
                subtype_xmlid="mail.mt_comment",
            )
        elif self.project_id:
            self.project_id.message_post(
                body=message,
                subtype_xmlid="mail.mt_comment",
            )

    def _log_success(self, number, data):
        """Registra envío exitoso en el chatter - solo muestra el mensaje."""
        # Convertir saltos de línea a <br/> y escapar HTML
        safe_message = (self.message or "").replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('\n', '<br/>')
        
        if self.lead_id:
            self.lead_id.message_post(
                body=Markup(safe_message),
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
            )
        if self.applicant_id:
            self.applicant_id.message_post(
                body=Markup(safe_message),
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
            )
        if self.partner_id:
            self.partner_id.message_post(
                body=Markup(safe_message),
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
            )
        if self.project_id:
            self.project_id.message_post(
                body=Markup(safe_message),
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
            )