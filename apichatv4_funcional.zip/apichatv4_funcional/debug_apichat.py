
import requests
import sys

# CONFIGURACION 
# Remplaza estos valores con los tuyos si no los pasas como argumentos
CLIENT_ID = "30280" # Tu ID de instancia
TOKEN = "SATs***RYMN" # Tu token (remplaza con el real)

if len(sys.argv) > 2:
    CLIENT_ID = sys.argv[1]
    TOKEN = sys.argv[2]

print(f"🔍 DEBUG APIChat - Instance: {CLIENT_ID}")
print("-" * 60)

tests = [
    {
        "name": "1. Status (Instance + URL Auth)",
        "url": f"https://api.apichat.io/instance{CLIENT_ID}/status?token={TOKEN}",
        "method": "GET",
        "headers": {},
        "expected": 200
    },
    {
        "name": "2. Status (Instance + Header Auth)",
        "url": f"https://api.apichat.io/instance{CLIENT_ID}/status",
        "method": "GET",
        "headers": {"client-id": CLIENT_ID, "token": TOKEN},
        "expected": 200
    },
    {
        "name": "3. Dialogs (Instance + URL Auth) [GET]",
        "url": f"https://api.apichat.io/instance{CLIENT_ID}/dialogs?token={TOKEN}&limit=1",
        "method": "GET",
        "headers": {},
        "expected": 200
    },
    {
        "name": "4. Dialogs (Instance + URL Auth) [POST]",
        "url": f"https://api.apichat.io/instance{CLIENT_ID}/dialogs?token={TOKEN}&limit=1",
        "method": "POST",
        "headers": {},
        "data": {},
        "expected": 200
    },
    {
        "name": "5. Dialogs (Instance + Header Auth) [GET]",
        "url": f"https://api.apichat.io/instance{CLIENT_ID}/dialogs?limit=1",
        "method": "GET",
        "headers": {"client-id": CLIENT_ID, "token": TOKEN},
        "expected": 200
    },
    {
        "name": "6. V1 Conversations (Header Auth) [GET]",
        "url": "https://api.apichat.io/v1/conversations?limit=1",
        "method": "GET",
        "headers": {"client-id": CLIENT_ID, "token": TOKEN},
        "expected": 200
    }
]

for t in tests:
    print(f"\n👉 Probando: {t['name']}")
    print(f"   URL: {t['url']}")
    try:
        if t['method'] == 'GET':
            resp = requests.get(t['url'], headers=t.get('headers'), timeout=15)
        else:
            resp = requests.post(t['url'], headers=t.get('headers'), json=t.get('data', {}), timeout=15)
            
        status = resp.status_code
        print(f"   Status: {status}")
        
        if status == 200:
            print("   ✅ ÉXITO")
            print(f"   Body: {resp.text[:100]}...")
        else:
            print("   ❌ FALLO")
            print(f"   Error: {resp.text[:200]}")
            
    except Exception as e:
        print(f"   ❌ EXCEPCIÓN: {e}")

print("\n" + "-" * 60)
print("🏁 Fin del diagnóstico")
