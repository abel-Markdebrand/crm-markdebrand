# keep these before res_partner import
from . import voip_country_code_mixin
from . import voip_queue_mixin

from . import voip_provider   # keep this before res_users_settings
from . import mail_activity
from . import res_partner
from . import res_users
from . import res_users_settings
from . import voip_call
from . import utils
