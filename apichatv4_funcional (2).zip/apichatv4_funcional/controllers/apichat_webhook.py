# -*- coding: utf-8 -*-
import json
import logging
from odoo import http
from odoo.http import request, Response

_logger = logging.getLogger(__name__)

class ApiChatWebhookController(http.Controller):

    @http.route('/apichat/webhook', type='http', auth='public', methods=['POST'], csrf=False)
    def apichat_webhook(self, **kwargs):
        """Controller ligero que delega la lógica al modelo."""
        try:
            _logger.info("=== 📩 WEBHOOK RECIBIDO ===")
            
            # 1. Verificación de Seguridad (Token)
            webhook_token = request.env['ir.config_parameter'].sudo().get_param('apichat.webhook_token')
            if webhook_token:
                request_token = kwargs.get('token')
                # También buscar en headers si no está en URL
                if not request_token:
                   request_token = request.httprequest.headers.get('Option-Token') or request.httprequest.headers.get('X-Waba-Webhook-Token')
                
                if request_token != webhook_token:
                    _logger.warning("⛔ Token de webhook inválido. Recibido: %s", request_token)
                    return Response(json.dumps({"status": "error", "message": "Unauthorized"}), status=401, content_type='application/json')

            # 2. Obtener Datos
            raw_data = request.httprequest.data
            if not raw_data:
                _logger.warning("⚠️ Datos vacíos recibidos")
                return Response(json.dumps({"status": "error", "message": "Empty data"}), content_type='application/json')

            raw_str = raw_data.decode('utf-8') if isinstance(raw_data, bytes) else str(raw_data)
            
            # 3. Guardar Mensaje Crudo
            try:
                raw_msg = request.env['apichat.raw.message'].sudo().create({
                    'raw_data': raw_str,
                })
                _logger.info("💾 JSON crudo guardado (ID: %s)", raw_msg.id)
            except Exception as e:
                _logger.error("❌ Error guardando raw message: %s", e)
                # No detenemos el proceso, intentamos procesar
                
            # 4. Procesar Mensaje (Delegar a Modelo)
            try:
                # Intentar parsear JSON para pasar una estructura limpia si es posible
                payload = json.loads(raw_str)
            except json.JSONDecodeError:
                payload = {}

            # Llamamos a un método en el modelo raw.message para procesar el negocio
            # Esto mantiene el controlador limpio
            processed_count = 0
            if payload and 'messages' in payload:
                # Lógica de negocio movida al modelo (se implementará un método helper allí)
                # Por ahora, mantendremos la compatibilidad llamando a la lógica existente si es necesario
                # O idealmente, invocar request.env['apichat.raw.message'].sudo().process_webhook_payload(payload)
                
                # Para evitar romper todo en este paso, voy a reimplementar la lógica usando métodos de modelo
                # que crearemos a continuación.
                pass 

            # NOTA: En este refactor, estamos moviendo la lógica pesada fuera.
            # Vamos a asumir que el modelo `apichat.raw.message` se encargará de esto en un cron o job,
            # o lo procesamos aquí mismo pero llamando al métodos del modelo.
            
            # Para cumplir el plan de "Clean Controller", delegamos:
            request.env['apichat.raw.message'].sudo().process_webhook_payload(payload)

            return Response(json.dumps({"status": "success", "message": "Received"}), content_type='application/json')

        except Exception as e:
            _logger.error("❌ Error crítico en webhook: %s", str(e), exc_info=True)
            return Response(json.dumps({"status": "error", "message": str(e)}), status=500, content_type='application/json')

    @http.route('/apichat/file/<int:attachment_id>/<string:access_token>', type='http', auth='public', methods=['GET'], csrf=False)
    def public_file_download(self, attachment_id, access_token, **kwargs):
        """Controlador público para descarga de archivos por APIChat."""
        try:
            # Buscar attachment
            attachment = request.env['ir.attachment'].sudo().browse(attachment_id)
            
            if not attachment.exists():
                _logger.warning("⚠️ Attachment %s no encontrado", attachment_id)
                return Response("File not found", status=404)
            
            # Verificar access_token
            if not attachment.access_token or attachment.access_token != access_token:
                _logger.warning("⛔ Token inválido para attachment %s", attachment_id)
                return Response("Unauthorized", status=401)
            
            # Obtener datos del archivo
            import base64
            file_data = base64.b64decode(attachment.datas) if attachment.datas else b''
            
            if not file_data:
                return Response("Empty file", status=404)
            
            # Preparar headers de respuesta
            headers = [
                ('Content-Type', attachment.mimetype or 'application/octet-stream'),
                ('Content-Disposition', f'inline; filename="{attachment.name}"'),
                ('Content-Length', str(len(file_data))),
                ('Cache-Control', 'public, max-age=3600'),
            ]
            
            _logger.info("📁 Sirviendo archivo público: %s (%s bytes)", attachment.name, len(file_data))
            
            return Response(file_data, headers=headers, status=200)
            
        except Exception as e:
            _logger.error("❌ Error sirviendo archivo: %s", str(e))
            return Response("Server error", status=500)