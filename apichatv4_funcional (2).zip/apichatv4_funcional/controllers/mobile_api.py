# -*- coding: utf-8 -*-
import json
import logging
import base64
from odoo import http
from odoo.http import request, Response

_logger = logging.getLogger(__name__)

class MobileApiChatController(http.Controller):

    def _get_json_payload(self):
        """Helper to get JSON payload from request."""
        try:
            return json.loads(request.httprequest.data)
        except Exception:
            return {}

    @http.route('/apichat/mobile/ping', type='http', auth='public', methods=['GET'], csrf=False)
    def ping(self):
        """Public endpoint to verify controller is loaded."""
        return Response(json.dumps({'status': 'ok', 'message': 'APIChat Mobile API is active'}), content_type='application/json')

    @http.route('/apichat/mobile/get_messages', type='http', auth='user', methods=['POST'], csrf=False)
    def get_messages(self, **kwargs):
        """Fetch message history for a partner."""
        payload = self._get_json_payload()
        partner_id = payload.get('partner_id')
        limit = payload.get('limit', 50)
        offset = payload.get('offset', 0)

        if not partner_id:
            return Response(json.dumps({'error': 'Missing partner_id'}), content_type='application/json', status=400)

        domain = [
            ('model', '=', 'res.partner'),
            ('res_id', '=', partner_id),
            ('message_type', 'in', ['comment', 'whatsapp'])
        ]
        
        messages = request.env['mail.message'].sudo().search(domain, limit=limit, offset=offset, order='date desc')
        
        result = []
        for msg in messages:
            state = 'delivered'
            is_outgoing = msg.author_id.id == request.env.user.partner_id.id
            
            # Use message_id safely
            m_id = msg.message_id or ''
            tracking = request.env['apichat.sent.message'].sudo().search([('message_id', '=', m_id)], limit=1)
            if tracking:
                state = tracking.status
            
            result.append({
                'id': msg.id,
                'body': msg.body,
                'type': 'text' if not msg.attachment_ids else 'image',
                'state': state,
                'isOutgoing': is_outgoing,
                'timestamp': msg.date.isoformat(),
            })
            
        return Response(json.dumps({'messages': result}), content_type='application/json')

    @http.route('/apichat/mobile/send_message', type='http', auth='user', methods=['POST'], csrf=False)
    def send_message(self, **kwargs):
        """Send a WhatsApp text message."""
        payload = self._get_json_payload()
        partner_id = payload.get('partner_id')
        body = payload.get('body')

        if not partner_id or not body:
            return Response(json.dumps({'success': False, 'error': 'Missing parameters'}), content_type='application/json', status=400)

        partner = request.env['res.partner'].sudo().browse(partner_id)
        if not partner.exists():
            return Response(json.dumps({'success': False, 'error': 'Partner not found'}), content_type='application/json', status=404)
        
        ok, data = partner._send_whatsapp_message(body)
        if ok:
            return Response(json.dumps({
                'success': True,
                'message_id': data.get('key', {}).get('id') if isinstance(data, dict) else None
            }), content_type='application/json')
        else:
            return Response(json.dumps({'success': False, 'error': str(data)}), content_type='application/json', status=500)

    @http.route('/apichat/mobile/send_audio', type='http', auth='user', methods=['POST'], csrf=False)
    def send_audio(self, **kwargs):
        """Send a WhatsApp audio message (Multipart)."""
        partner_id = int(kwargs.get('partner_id', 0))
        audio_file = kwargs.get('audio')
        
        if not partner_id or not audio_file:
            return Response(json.dumps({'success': False, 'error': 'Missing parameters'}), content_type='application/json', status=400)
            
        partner = request.env['res.partner'].sudo().browse(partner_id)
        if not partner.exists():
            return Response(json.dumps({'success': False, 'error': 'Partner not found'}), content_type='application/json', status=404)

        attachment = request.env['ir.attachment'].sudo().create({
            'name': audio_file.filename or 'whatsapp_audio.m4a',
            'datas': base64.b64encode(audio_file.read()),
            'res_model': 'res.partner',
            'res_id': partner_id,
            'mimetype': 'audio/m4a'
        })
        
        ok, data = partner._send_whatsapp_media(attachment, caption="")
        if ok:
            return Response(json.dumps({
                'success': True,
                'message_id': data.get('key', {}).get('id') if isinstance(data, dict) else None
            }), content_type='application/json')
        else:
            return Response(json.dumps({'success': False, 'error': str(data)}), content_type='application/json', status=500)

    @http.route('/apichat/mobile/poll_messages', type='http', auth='user', methods=['POST'], csrf=False)
    def poll_messages(self, **kwargs):
        """Check for new messages."""
        payload = self._get_json_payload()
        partner_id = payload.get('partner_id')
        last_message_id = payload.get('last_message_id')

        if not partner_id:
            return Response(json.dumps({'error': 'Missing partner_id'}), content_type='application/json', status=400)

        domain = [
            ('model', '=', 'res.partner'),
            ('res_id', '=', partner_id),
        ]
        if last_message_id:
            domain.append(('id', '>', last_message_id))
        
        new_messages = request.env['mail.message'].sudo().search(domain, order='date asc')
        
        result = []
        for msg in new_messages:
             result.append({
                'id': msg.id,
                'body': msg.body,
                'type': 'text',
                'state': 'delivered',
                'isOutgoing': msg.author_id.id == request.env.user.partner_id.id,
                'timestamp': msg.date.isoformat(),
            })
            
        return Response(json.dumps({'messages': result}), content_type='application/json')

