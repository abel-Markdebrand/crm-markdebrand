def post_init_create_channel(env):
    """
    Crea un canal de WhatsApp si no existe.
    Soporta Odoo 16- (mail.channel) y Odoo 17+ (discuss.channel).
    """
    # Determinar el modelo de canal disponible
    if 'discuss.channel' in env.registry.models:
        model_name = 'discuss.channel'
    elif 'mail.channel' in env.registry.models:
        model_name = 'mail.channel'
    else:
        # No hay módulo de chat instalado
        return

    Channel = env[model_name].sudo()
    
    # Buscar canal existente
    channel = Channel.search([('name', '=', 'WhatsApp Inbox')], limit=1)
    if not channel:
        Channel.create({
            'name': 'WhatsApp Inbox',
            'channel_type': 'channel',
            # 'public' field validity depends on version, safe defaults usually work or omitted for private
            # For Odoo 17+, 'public' might be 'group_public' or handled differently
            # We'll try basic creation
        })
