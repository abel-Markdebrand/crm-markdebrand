# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api

_logger = logging.getLogger(__name__)


class ApichatSentMessage(models.Model):
    """Tracks outgoing WhatsApp messages and their delivery status."""
    _name = "apichat.sent.message"
    _description = "Mensajes WhatsApp Enviados"
    _order = "create_date desc"
    _rec_name = "display_name"

    # Message identification
    message_id = fields.Char(
        string="Message ID",
        required=True,
        index=True,
        help="ID único del mensaje en WhatsApp (key.id de Evolution API)"
    )
    remote_jid = fields.Char(
        string="Destinatario",
        required=True,
        index=True,
        help="JID del destinatario (número@s.whatsapp.net o grupo@g.us)"
    )
    
    # Content
    message_type = fields.Selection([
        ('text', 'Texto'),
        ('image', 'Imagen'),
        ('video', 'Video'),
        ('audio', 'Audio'),
        ('document', 'Documento'),
        ('reaction', 'Reacción'),
    ], string="Tipo", default='text')
    content = fields.Text(string="Contenido", help="Texto del mensaje o caption")
    
    # Status tracking
    status = fields.Selection([
        ('pending', 'Pendiente'),
        ('server_ack', 'En Servidor ✓'),
        ('delivered', 'Entregado ✓✓'),
        ('read', 'Leído 🔵'),
        ('failed', 'Fallido ❌'),
    ], string="Estado", default='pending', tracking=True)
    
    status_icon = fields.Char(
        string="Icono",
        compute="_compute_status_icon",
        help="Icono visual del estado"
    )
    
    # Timestamps
    sent_at = fields.Datetime(
        string="Enviado",
        default=fields.Datetime.now
    )
    delivered_at = fields.Datetime(string="Entregado")
    read_at = fields.Datetime(string="Leído")
    
    # Relationships
    lead_id = fields.Many2one('crm.lead', string="Lead", ondelete='set null')
    partner_id = fields.Many2one('res.partner', string="Contacto", ondelete='set null')
    user_id = fields.Many2one('res.users', string="Enviado por", default=lambda self: self.env.user)
    
    # Display
    display_name = fields.Char(compute="_compute_display_name", store=True)

    @api.depends('remote_jid', 'message_type', 'status')
    def _compute_display_name(self):
        for rec in self:
            jid_short = rec.remote_jid.split('@')[0] if rec.remote_jid else 'N/A'
            rec.display_name = f"{rec.message_type} → {jid_short[:15]} [{rec.status}]"

    @api.depends('status')
    def _compute_status_icon(self):
        icons = {
            'pending': '⏳',
            'server_ack': '✓',
            'delivered': '✓✓',
            'read': '🔵',
            'failed': '❌',
        }
        for rec in self:
            rec.status_icon = icons.get(rec.status, '?')

    @api.model
    def create_from_send_result(self, data, lead=None, partner=None, msg_type='text', content=''):
        """Create a tracking record from Evolution API send response."""
        key = data.get('key', {})
        message_id = key.get('id')
        remote_jid = key.get('remoteJid')
        
        if not message_id:
            _logger.warning("No message_id in send response, skipping tracking")
            return None
        
        vals = {
            'message_id': message_id,
            'remote_jid': remote_jid or '',
            'message_type': msg_type,
            'content': content[:500] if content else '',
            'status': 'server_ack',  # Evolution confirma al enviar
        }
        
        if lead:
            vals['lead_id'] = lead.id
        if partner:
            vals['partner_id'] = partner.id
            
        return self.create(vals)

    @api.model
    def update_status_from_webhook(self, message_id, new_status, timestamp=None):
        """Update message status from MESSAGES_UPDATE webhook event."""
        record = self.search([('message_id', '=', message_id)], limit=1)
        if not record:
            _logger.debug("Message %s not found for status update", message_id)
            return False
        
        # Map Evolution status to our status
        status_map = {
            'SERVER_ACK': 'server_ack',
            'DELIVERY_ACK': 'delivered',
            'READ': 'read',
            'PLAYED': 'read',  # For audio/video
            'ERROR': 'failed',
        }
        
        mapped_status = status_map.get(new_status.upper(), None)
        if not mapped_status:
            _logger.debug("Unknown status %s for message %s", new_status, message_id)
            return False
        
        update_vals = {'status': mapped_status}
        
        if mapped_status == 'delivered' and timestamp:
            update_vals['delivered_at'] = timestamp
        elif mapped_status == 'read' and timestamp:
            update_vals['read_at'] = timestamp
            
        record.write(update_vals)
        _logger.info("📊 Message %s status updated: %s → %s", message_id, record.status, mapped_status)
        return True
