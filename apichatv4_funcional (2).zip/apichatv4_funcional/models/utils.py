# -*- coding: utf-8 -*-
import re
import logging

_logger = logging.getLogger(__name__)


# Tipos MIME soportados
IMAGE_MIMES = {'image/jpeg', 'image/png', 'image/webp', 'image/gif'}
DOCUMENT_MIMES = {'application/pdf', 'application/msword', 
                  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                  'application/vnd.ms-excel', 'text/plain', 'text/csv'}
AUDIO_MIMES = {'audio/mpeg', 'audio/mp3', 'audio/ogg', 'audio/opus', 'audio/wav', 
               'audio/x-wav', 'audio/aac', 'audio/m4a', 'audio/x-m4a'}
VIDEO_MIMES = {'video/mp4', 'video/3gpp', 'video/quicktime', 'video/webm', 
               'video/x-msvideo', 'video/mpeg'}


def normalize_phone(phone):
    """
    Normaliza número telefónico removiendo caracteres no numéricos.
    
    Args:
        phone (str): Número telefónico en cualquier formato
        
    Returns:
        str: Número normalizado solo con dígitos
    """
    if not phone:
        return ""
    return re.sub(r"\D+", "", phone)


def is_send_ok(response):
    """
    Verifica si la respuesta de la API de APIChat indica éxito en el envío.
    
    Args:
        response (requests.Response): Respuesta HTTP de la API
        
    Returns:
        tuple: (bool éxito, dict datos)
    """
    if not response.ok:
        return False, {}
    
    try:
        data = response.json()
    except Exception as e:
        _logger.warning("No se pudo parsear JSON de respuesta: %s", e)
        return False, {}
    
    # Verificar múltiples indicadores de éxito
    success = bool(data.get("success"))
    message_id = data.get("messageId") or data.get("id") or data.get("message_id")
    # Evolution API devuelve key.id para mensajes exitosos
    if not message_id and isinstance(data.get("key"), dict):
        message_id = data["key"].get("id")
    status = (data.get("status") or "").lower()
    
    ok = success or message_id or status in {"sent", "delivered", "queued", "pending"}
    
    return bool(ok), data


def get_media_type(mimetype):
    """Determina el tipo de media basado en el MIME type para Evolution API."""
    if mimetype in IMAGE_MIMES:
        return 'image'
    elif mimetype in VIDEO_MIMES:
        return 'video'
    elif mimetype in AUDIO_MIMES:
        return 'audio'
    elif mimetype in DOCUMENT_MIMES:
        return 'document'
    return 'document'
