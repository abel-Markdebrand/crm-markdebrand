# -*- coding: utf-8 -*-

from . import constants
from . import utils

from . import apichat_group
from . import apichat_raw_message
from . import crm_lead
from . import hr_applicant
from . import res_config_settings
from . import res_partner
from . import project_project
from . import apichat_sent_message