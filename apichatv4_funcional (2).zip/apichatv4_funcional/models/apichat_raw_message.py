# -*- coding: utf-8 -*-
import base64
import json
import logging
import requests
import re
from datetime import datetime, timezone
from markupsafe import Markup
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

def _esc(s):
    return (s or '').replace('<', '&lt;').replace('>', '&gt;')

def _digits(s):
    return re.sub(r'\D+', '', s or '')

class ApiChatRawMessage(models.Model):
    _name = "apichat.raw.message"
    _description = "Mensajes crudos recibidos desde APIChat"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = "create_date desc"
    _rec_name = "display_name"

    raw_data = fields.Text(
        string="Datos Crudos",
        required=True,
        help="JSON o texto crudo recibido desde el webhook"
    )
    display_name = fields.Char(
        string="Resumen",
        compute="_compute_display_name",
        store=True
    )
    phone_number = fields.Char(
        string="Número de Teléfono",
        compute="_compute_parsed_fields",
        store=True,
        index=True
    )
    message_text = fields.Text(
        string="Mensaje",
        compute="_compute_parsed_fields",
        store=True
    )
    formatted_json = fields.Text(
        string="JSON Formateado",
        compute="_compute_formatted_json"
    )

    # Campos de control de envío a webhook
    webhook_sent = fields.Boolean(
        string="Enviado a Webhook", 
        default=False, 
        readonly=True
    )
    webhook_status_code = fields.Char(
        string="Código HTTP", 
        readonly=True
    )
    webhook_response = fields.Text(
        string="Respuesta del Webhook", 
        readonly=True
    )
    webhook_sent_at = fields.Datetime(
        string="Fecha de Envío", 
        readonly=True
    )

    # Relación con CRM Lead (opcional)
    lead_id = fields.Many2one(
        'crm.lead', 
        string="Lead Relacionado", 
        ondelete='set null',
        index=True
    )
    
    # Campos para media recibida
    attachment_id = fields.Many2one(
        'ir.attachment',
        string="Archivo Adjunto",
        ondelete='set null'
    )
    media_type = fields.Selection([
        ('text', 'Texto'),
        ('image', 'Imagen'),
        ('document', 'Documento'),
    ], default='text', string="Tipo de Media")
    
    # Campos para mensajes de grupos
    is_group_message = fields.Boolean(
        string="Mensaje de Grupo",
        default=False,
        help="Indica si el mensaje proviene de un grupo de WhatsApp"
    )
    group_chat_id = fields.Char(
        string="ID del Grupo",
        index=True,
        help="ID del grupo de WhatsApp de donde provino el mensaje"
    )

    @api.depends("raw_data")
    def _compute_display_name(self):
        """Genera un nombre descriptivo para el registro."""
        for rec in self:
            if not rec.raw_data:
                rec.display_name = _("(vacío)")
                continue
            
            rd = rec.raw_data.strip()
            if len(rd) > 60:
                rec.display_name = rd[:60] + "..."
            else:
                rec.display_name = rd

    @api.depends("raw_data")
    def _compute_parsed_fields(self):
        """Extrae número y mensaje del JSON si está disponible."""
        for rec in self:
            rec.phone_number = False
            rec.message_text = False
            
            rd = (rec.raw_data or "").strip()
            if not rd:
                continue
            
            try:
                data = json.loads(rd)
                
                # Safety check: if list, take first item or wrapper
                if isinstance(data, list):
                    data = data[0] if data else {}
                
                # Evolution API Payload extraction
                # Structure: { "type": "...", "data": { "key": { "remoteJid": ... }, "message": { ... } } }
                evo_data = data.get('data') or {}
                evo_key = evo_data.get('key') or {}
                evo_msg = evo_data.get('message') or {}
                
                # Intentar extraer número de teléfono
                raw_phone = (
                    data.get("phone") or 
                    data.get("from") or 
                    data.get("phoneNumber") or
                    data.get("sender") or
                    # Evolution API
                    evo_key.get('remoteJid') or
                    evo_data.get('pushName') # Fallback if no remoteJid inside key? usually key has it
                )
                
                if raw_phone:
                    rec.phone_number = _digits(str(raw_phone))
                else:
                    rec.phone_number = False
                
                # Intentar extraer mensaje
                rec.message_text = (
                    data.get("message") or 
                    data.get("text") or 
                    data.get("body") or
                    data.get("content") or
                    # Evolution API
                    evo_msg.get('conversation') or
                    evo_msg.get('extendedTextMessage', {}).get('text') or
                    evo_msg.get('imageMessage', {}).get('caption') or
                    evo_msg.get('videoMessage', {}).get('caption') or
                    evo_msg.get('documentMessage', {}).get('caption')
                )
                
            except json.JSONDecodeError:
                _logger.debug("raw_data no es JSON válido (id %s)", rec.id)
            except Exception as e:
                _logger.warning("Error al parsear raw_data (id %s): %s", rec.id, e)

    @api.depends("raw_data")
    def _compute_formatted_json(self):
        """Formatea el JSON para mejor visualización."""
        for rec in self:
            rd = (rec.raw_data or "").strip()
            if not rd:
                rec.formatted_json = ""
                continue
            
            try:
                obj = json.loads(rd)
                rec.formatted_json = json.dumps(obj, indent=2, ensure_ascii=False)
            except json.JSONDecodeError:
                rec.formatted_json = rd

    @api.model
    def _webhook_enabled(self):
        """Verifica si el switch de auto-forward está activo en res.config.settings."""
        try:
            # config = self.env['apichat.config'].sudo().get_active()
            # is_enabled = bool(config.webhook_auto_forward)
            is_enabled = self.env['ir.config_parameter'].sudo().get_param('apichat.webhook_auto_forward')
            _logger.debug("🔄 Switch webhook_auto_forward: %s", is_enabled)
            return bool(is_enabled)
        except Exception as e:
            _logger.warning("⚠️ No se pudo leer webhook_auto_forward: %s", e)
            return False

    @api.model
    def _get_webhook_url(self):
        """Obtiene la URL del webhook desde res.config.settings."""
        try:
            # config = self.env['apichat.config'].sudo().get_active()
            # url = (config.webhook_url or "").strip()
            url = self.env['ir.config_parameter'].sudo().get_param('apichat.webhook_url', '').strip()
            return url if url else False
        except Exception as e:
            _logger.warning("⚠️ No se pudo obtener webhook_url: %s", e)
            return False

    @api.model_create_multi
    def create(self, vals_list):
        """Al crear mensaje crudo, intenta enviarlo al webhook y crear/actualizar lead."""
        records = super().create(vals_list)
        
        # 1. Auto-forward al webhook si está habilitado
        if self._webhook_enabled():
            _logger.info("🔄 Auto-forward ACTIVADO: procesando %s mensaje(s)", len(records))
            for rec in records:
                try:
                    rec.action_send_to_webhook()
                    _logger.info("✅ Auto-forward exitoso para mensaje id %s", rec.id)
                except Exception as e:
                    _logger.exception("❌ Auto-forward falló para mensaje id %s: %s", rec.id, e)
        else:
            _logger.debug("⏸️ Auto-forward DESACTIVADO: mensajes guardados sin enviar")
        
        # 2. Auto-crear/actualizar lead en CRM si hay número de teléfono
        for rec in records:
            try:
                if rec.phone_number:
                    lead = self.env['crm.lead']._find_or_create_lead_by_phone(rec.phone_number)
                    
                    # Vincular el mensaje con el lead
                    rec.sudo().write({'lead_id': lead.id})
                    
                    # Publicar mensaje en el chatter del lead
                    if rec.message_text:
                        lead.message_post(
                            body=Markup(_("📩 <strong>WhatsApp entrante:</strong><br/>%s") % _esc(rec.message_text)),
                            subtype_xmlid='mail.mt_comment'
                        )
                    else:
                        lead.message_post(
                            body=Markup(_("📩 <strong>WhatsApp entrante</strong> (sin texto)")),
                            subtype_xmlid='mail.mt_note'
                        )
                    
                    _logger.info("🔗 Mensaje WhatsApp vinculado a lead %s (id %s)", lead.name, lead.id)
                    
            except Exception as e:
                _logger.exception("❌ Error al crear/actualizar lead desde mensaje crudo: %s", e)
        
        return records

    def action_send_to_webhook(self):
        """Envía el mensaje crudo al webhook configurado."""
        url = self._get_webhook_url()
        if not url:
            raise UserError(_("No hay URL de webhook configurada.\n\nVe a: WhatsApp API > Configuración > Webhook n8n"))

        for rec in self:
            rd = (rec.raw_data or "").strip()
            if not rd:
                raise UserError(_("Este registro no tiene 'Datos Crudos'."))

            # Obtener configuración de timeout y SSL
            try:
                # config = self.env['apichat.config'].sudo().get_active()
                # timeout = int(config.webhook_timeout or 20)
                # verify_ssl = bool(config.webhook_verify_ssl)
                timeout = int(self.env['ir.config_parameter'].sudo().get_param('apichat.webhook_timeout', 20))
                verify_ssl = bool(self.env['ir.config_parameter'].sudo().get_param('apichat.webhook_verify_ssl', True))
            except Exception:
                timeout = 20
                verify_ssl = True
            
            _logger.info("📤 Enviando mensaje id %s a webhook: %s (timeout=%ss, verify_ssl=%s)", 
                        rec.id, url, timeout, verify_ssl)
            
            try:
                # Intentar parsear como JSON
                try:
                    body = json.loads(rd)
                    headers = {
                        'Content-Type': 'application/json',
                        'User-Agent': 'Odoo-APIChat/19.0'
                    }
                    resp = requests.post(
                        url, 
                        json=body, 
                        headers=headers, 
                        timeout=timeout,
                        verify=verify_ssl
                    )
                except json.JSONDecodeError:
                    # Si no es JSON, enviar como texto plano
                    _logger.debug("raw_data no es JSON, enviando como texto plano")
                    headers = {
                        'Content-Type': 'text/plain; charset=utf-8',
                        'User-Agent': 'Odoo-APIChat/19.0'
                    }
                    resp = requests.post(
                        url, 
                        data=rd.encode('utf-8'), 
                        headers=headers, 
                        timeout=timeout,
                        verify=verify_ssl
                    )
                
            except requests.Timeout:
                error_msg = _("⏱️ Timeout: El webhook no respondió en %s segundos") % timeout
                rec.sudo().write({
                    'webhook_sent': False,
                    'webhook_status_code': 'TIMEOUT',
                    'webhook_response': error_msg,
                    'webhook_sent_at': fields.Datetime.now(),
                })
                _logger.error("❌ Webhook timeout: %s (id %s)", url, rec.id)
                raise UserError(error_msg)
                
            except requests.ConnectionError as e:
                error_msg = _("🔌 Error de conexión: %s") % str(e)
                rec.sudo().write({
                    'webhook_sent': False,
                    'webhook_status_code': 'CONNECTION_ERROR',
                    'webhook_response': error_msg[:4000],
                    'webhook_sent_at': fields.Datetime.now(),
                })
                _logger.error("❌ Webhook connection error: %s (id %s)", e, rec.id)
                raise UserError(error_msg)
                
            except requests.RequestException as e:
                error_msg = _("⚠️ Error de solicitud: %s") % str(e)
                rec.sudo().write({
                    'webhook_sent': False,
                    'webhook_status_code': 'REQUEST_ERROR',
                    'webhook_response': error_msg[:4000],
                    'webhook_sent_at': fields.Datetime.now(),
                })
                _logger.exception("❌ Webhook request failed (id %s): %s", rec.id, e)
                raise UserError(error_msg)

            # Guardar resultado
            rec.sudo().write({
                'webhook_sent': resp.ok,
                'webhook_status_code': str(resp.status_code),
                'webhook_response': resp.text[:4000],
                'webhook_sent_at': fields.Datetime.now(),
            })
            
            if resp.ok:
                _logger.info("✅ Webhook POST exitoso: %s -> %s (id %s)", url, resp.status_code, rec.id)
            else:
                _logger.warning("⚠️ Webhook POST falló: %s -> %s (id %s)\nRespuesta: %s", 
                               url, resp.status_code, rec.id, resp.text[:200])


    @api.model
    def process_webhook_payload(self, payload):
        """Procesa el payload recibido del webhook (Logica movida desde el controlador)."""
        _logger.info("🔍 Procesando payload webhook: keys=%s", list(payload.keys()) if isinstance(payload, dict) else type(payload))
        
        # 5. Manejar evento MESSAGES_UPDATE (Status updates)
        event_type = payload.get('event') or payload.get('type')
        _logger.info("Event Type Detected: %s", event_type)
        
        # Ignorar eventos que no son mensajes ni actualizaciones de estado
        if event_type in ['contacts.update', 'presence.update', 'chats.update', 'chats.set']:
            _logger.info("⏩ Ignorando evento informativo: %s", event_type)
            return 0
        
        messages = []
        
        # 1. Intentar estructura estándar {"messages": [...]}
        if isinstance(payload, dict) and 'messages' in payload:
             messages = payload['messages']
             
        # 2. Intentar estructura directa lista [...]
        elif isinstance(payload, list):
             messages = payload
             
        # 3. Intentar mensaje único directo {...} pero verificando que parezca un mensaje
        elif isinstance(payload, dict) and ('chatId' in payload or 'body' in payload or 'groupName' in payload):
             messages = [payload]
        
        # 4. Fallback: payload.get('data') - Evolution API suele enviar aquí el objeto mensaje ENVOLTORIO
        # Evolution Structure: { "type": "MESSAGES_UPSERT", "data": { ... message object ... } }
        elif isinstance(payload, dict) and 'data' in payload:
             data_content = payload['data']
             # IMPORTANTE: Evolution API a veces manda el mensaje DIRECTO en data, o dentro de data.message?
             # Normalmente data ES el mensaje (tiene key, pushName, message, messageTimestamp)
             if isinstance(data_content, dict):
                 # Verificar si es un mensaje válido antes de agregarlo
                 if 'key' in data_content or 'message' in data_content:
                     messages = [data_content]
                 else:
                     _logger.info("⚠️ Data content no parece un mensaje: keys=%s", list(data_content.keys()))
             elif isinstance(data_content, list):
                 messages = data_content

        _logger.info("🔢 Mensajes extraídos para procesar: %s", len(messages))
        
        if event_type and event_type.upper() in ['MESSAGES_UPDATE', 'MESSAGES.UPDATE']:
             data = payload.get('data')
             if data:
                 # Evolution sends { key: ..., status: ... }
                 key = data.get('key', {})
                 msg_id = key.get('id') or data.get('keyId') or data.get('messageId')
                 status = data.get('status')
                 timestamp = data.get('timestamp') or data.get('messageTimestamp')
                 
                 if msg_id and status:
                     # Convertir timestamp si es necesario
                     ts = None
                     if timestamp:
                         try:
                             # Evolution a veces manda segundos, a veces milisegundos?
                             # Asumiendo segundos si es < 3000000000
                             ts_val = int(timestamp)
                             if ts_val > 3000000000: ts_val /= 1000
                             ts = datetime.fromtimestamp(ts_val, timezone.utc)
                         except: pass
                         
                     self.env['apichat.sent.message'].update_status_from_webhook(msg_id, status, timestamp=ts)
                     return 1 # Procesado

        processed_count = 0
        if messages:
            for message in messages:
                if self._process_single_message(message):
                    processed_count += 1
        return processed_count

    def _process_single_message(self, message):
        try:
            # 1. Extracción robusta de IDs (Soporte Evolution API y APIChat)
            key = message.get('key', {})
            
            # Evolution API: remoteJid
            msg_from = message.get('from') or message.get('chatId') or key.get('remoteJid') or ''
            
            # Evolution API 2.3.7+ maneja LID normalization automáticamente
            # Si aún llega un LID, lo ignoramos ya que no podemos identificar al remitente
            if '@lid' in str(msg_from):
                _logger.warning("⚠️ Mensaje con LID no normalizado: %s (pushName: %s)", msg_from, message.get('pushName'))
                _logger.info("   Evolution API debería normalizar LIDs automáticamente en v2.3.7+")
                return False

            # Evolution API: participant (en grupos)
            msg_author = message.get('author') or message.get('sender', {}).get('id') or key.get('participant') or ''
            
            # Detectar si es grupo
            is_group = (
                message.get('is_group') or 
                message.get('chat_type') == 'group' or 
                '@g.us' in str(msg_from) or 
                '@g.us' in str(message.get('chatId', ''))
            )
            
            if is_group:
                group_id = msg_from # En grupos, 'from' es el ID del grupo
                from_msisdn = msg_author # El autor es quien escribe
                # Fallback: si no hay author, intentar usar number
                if not from_msisdn:
                     from_msisdn = message.get('number') or ''
            else:
                group_id = False
                from_msisdn = msg_from # En privado, 'from' es quien escribe
            
            # Extracción del cuerpo del mensaje (Evolution API)
            msg_content = message.get('message', {})
            
            # Buscar en todos los tipos posibles de mensaje
            body_text = (
                message.get('text') or 
                message.get('body') or 
                message.get('caption') or 
                msg_content.get('conversation') or 
                msg_content.get('extendedTextMessage', {}).get('text') or 
                msg_content.get('imageMessage', {}).get('caption') or
                msg_content.get('documentMessage', {}).get('caption') or 
                msg_content.get('videoMessage', {}).get('caption') or 
                msg_content.get('audioMessage', {}).get('caption') or 
                ''
            )
            
            message_type = message.get('type') or message.get('messageType') or 'text'
            timestamp = message.get('time') or message.get('timestamp') or message.get('messageTimestamp')
            
            from_me = message.get('from_me', False) or message.get('fromMe', False) or key.get('fromMe', False)
            
            _logger.info("Msg Detail: from=%s, from_me=%s, type=%s, body_len=%s", from_msisdn, from_me, message_type, len(body_text))

            # Ignorar mensajes salientes
            if from_me:
                _logger.info("⏩ Ignorando mensaje saliente (fromMe=True)")
                return False
            
            # Campos de media
            # Evolution suele mandar esto en message.imageMessage, etc. 
            media_msg = msg_content.get('imageMessage') or msg_content.get('documentMessage') or msg_content.get('videoMessage') or msg_content.get('audioMessage')
            
            media_url = message.get('url') or message.get('media_url') or message.get('file_url') or message.get('body') 
            
            # Si no hay URL directa, intentar buscarla en el objeto de media
            if not media_url and media_msg:
                # Evolution a veces manda 'url' que es interna de WhatsApp, no descargable públicamente sin auth?
                # Evolution suele requerir convertir a base64 si no se usa S3.
                # Si llega webhook base64, vendrá en otro campo? Evolution manda 'base64' si está activo.
                media_url = media_msg.get('url') # Ojo con esto
                
            # Soporte para Base64 directo de Evolution
            base64_data = message.get('base64') # Evolution manda esto si 'Webhook Base64' está activo
            
            # Extraer mimetype y filename desde el objeto de media si existen
            mime_type = message.get('mime_type') or message.get('mimetype') or ''
            filename = message.get('filename') or message.get('file_name') or ''
            
            if media_msg and not mime_type:
                mime_type = media_msg.get('mimetype') or media_msg.get('mimeType') or ''
            if media_msg and not filename:
                filename = media_msg.get('fileName') or media_msg.get('filename') or ''
            
            # Extraer messageId para uso con Evolution API
            message_id = key.get('id') or message.get('messageId') or message.get('message_id') or ''
            
            caption = message.get('caption') or ''
            
            # Si is_group no estaba marcado pero el ID es de grupo, forzarlo
            if not is_group and group_id and '@g.us' in str(group_id):
                is_group = True

            # Procesar mensajes de grupos
            if is_group and group_id:
                _logger.info("👥 Mensaje de grupo detectado: %s", group_id)
                return self._process_group_message(
                    group_id, from_msisdn, body_text, message_type, timestamp,
                    media_url, mime_type, filename, caption, message_id, message
                )

            # Flujo normal para mensajes directos
            norm = _digits(str(from_msisdn)) if from_msisdn else ''
            if not norm:
                return False

            # Descargar y almacenar media
            attachment = False
            detected_media_type = 'text'
            
            # Normalizar tipos de mensaje
            is_image = message_type in ('image', 'imageMessage')
            is_document = message_type in ('document', 'documentMessage', 'file', 'pdf')
            is_video = message_type in ('video', 'videoMessage')
            is_audio = message_type in ('audio', 'audioMessage')
            
            if (is_image or is_document or is_video or is_audio) and (media_url or base64_data or message_id):
                _logger.info("📥 Media %s: %s (%s)", message_type, filename or 'sin nombre', mime_type or 'mime desconocido')
                
                # Caso 1: Tiene Base64 directo (común en Evolution con Webhook Base64 activo)
                if base64_data:
                    try:
                        # Determinar extensión y mimetype por defecto si faltan
                        if is_image:
                            def_ext, def_mime = 'jpg', 'image/jpeg'
                        elif is_video:
                            def_ext, def_mime = 'mp4', 'video/mp4'
                        elif is_audio:
                            def_ext, def_mime = 'mp3', 'audio/mpeg' # O ogg/aac dependiendo de WhatsApp
                        else:
                            def_ext, def_mime = 'pdf', 'application/pdf'
                            
                        # Determinar nombre (Evolution a veces manda 'file.enc' o sin nombre)
                        # Si viene como 'file.enc', forzamos el renombrado para que Odoo lo reconozca
                        if not filename or filename == 'file.enc':
                            filename = f"whatsapp_media_{timestamp}.{def_ext}"
                        
                        # Crear attachment directamente
                        attachment = self.env['ir.attachment'].create({
                            'name': filename,
                            'type': 'binary',
                            'datas': base64_data, # Evolution manda el base64 limpio usualmente
                            'res_model': 'mail.message', # Se vinculará luego
                            'res_id': 0,
                            'mimetype': mime_type or def_mime
                        })
                        _logger.info("✅ Base64 → %s", filename)
                    except Exception as e:
                        _logger.error("❌ Error creando attachment desde Base64: %s", e)

                # Caso 2: Tiene messageId - SIEMPRE usar Evolution API (la URL de WhatsApp está encriptada)
                elif message_id:
                    attachment = self._download_media_from_evolution(message_id, message_type, mime_type, filename, message)
                
                # Caso 3: Solo tiene URL (fallback legacy para casos extremos)
                elif media_url and media_url.startswith('http'):
                    _logger.warning("⚠️ Usando descarga directa desde URL (legacy, probablemente encriptada): %s", media_url[:100])
                    attachment = self._download_and_save_media(media_url, message_type, mime_type, filename)
                
                if attachment:
                    if is_image: detected_media_type = 'image'
                    elif is_video: detected_media_type = 'video'
                    elif is_audio: detected_media_type = 'audio'
                    else: detected_media_type = 'document'
            
            # Si hay caption, usarlo como texto adicional
            if caption and not body_text:
                body_text = caption

            return self._process_incoming_message_crm_and_partner(
                norm, body_text, message_type, timestamp, 
                attachment=attachment, media_type=detected_media_type
            )
        except Exception as e:
            _logger.error("❌ Error procesando mensaje individual: %s", e)
            return False
    
    def _process_group_message(self, group_id, from_msisdn, body_text, message_type, timestamp, 
                               media_url, mime_type, filename, caption, message_id=None, message=None):
        """
        Procesa un mensaje recibido de un grupo de WhatsApp.
        Opción A: Solo enruta a leads que tengan ESE grupo asignado.
        """
        try:
            # Verificar si la funcionalidad de grupos está habilitada
            groups_enabled = self.env['ir.config_parameter'].sudo().get_param('apichat.groups_enabled', False)
            if not groups_enabled:
                _logger.debug("⏸️ Grupos deshabilitados, ignorando mensaje de grupo %s", group_id)
                return False
            
            # Buscar leads que tengan este grupo asignado
            leads = self.env['crm.lead'].find_leads_by_group_id(group_id)
            
            if not leads:
                _logger.info("🚫 Mensaje de grupo %s ignorado: no hay leads con este grupo asignado", group_id)
                return False
            
            _logger.info("✅ Leads encontrados para grupo %s: %s (ids %s)", group_id, len(leads), leads.ids)
            
            # Descargar media si existe
            attachment = False
            detected_media_type = 'text'
            
            # Normalizar tipos de mensaje
            is_image = message_type in ('image', 'imageMessage')
            is_document = message_type in ('document', 'documentMessage', 'file', 'pdf')
            is_video = message_type in ('video', 'videoMessage')
            is_audio = message_type in ('audio', 'audioMessage')
            
            if (is_image or is_document or is_video or is_audio):
                # Preferir Evolution API si hay messageId (la URL de WhatsApp siempre está encriptada)
                if message_id and message:
                    attachment = self._download_media_from_evolution(message_id, message_type, mime_type, filename, message)
                # Fallback a descarga directa solo si NO hay messageId
                elif media_url and media_url.startswith('http'):
                    attachment = self._download_and_save_media(media_url, message_type, mime_type, filename)
                
                if attachment:
                    if is_image: detected_media_type = 'image'
                    elif is_video: detected_media_type = 'video'
                    elif is_audio: detected_media_type = 'audio'
                    else: detected_media_type = 'document'
            
            if caption and not body_text:
                body_text = caption
            
            # Construir cuerpo del mensaje
            from_number = _digits(str(from_msisdn)) if from_msisdn else ''
            
            # Buscar nombre del grupo en apichat.group
            group_record = self.env['apichat.group'].sudo().search([('group_id', '=', group_id)], limit=1)
            group_label = group_record.name if group_record else group_id
            
            # Buscar si el remitente es un contacto conocido
            from_label = from_number or 'Desconocido'
            if from_number:
                partner = self._find_partner_by_phone(from_number)
                if partner:
                    from_label = f"{partner.name} ({from_number})"
            
            body = f"👥 <b>Grupo:</b> {_esc(group_label)}<br/>"
            body += f"👤 <b>De:</b> {_esc(from_label)}<br/>"
            if body_text:
                body += f"<br/>{_esc(body_text)}"
            
            if attachment and detected_media_type != 'text':
                media_icon = "🖼️" if detected_media_type == 'image' else "📄"
                body = f"{media_icon} <b>{attachment.name}</b><br/>{body}"
            
            # Publicar en TODOS los leads encontrados
            success_count = 0
            for lead in leads:
                try:
                    lead.sudo().message_post(
                        body=Markup(body),
                        message_type='comment',
                        subtype_xmlid='mail.mt_comment',
                        attachments=[(attachment.name, base64.b64decode(attachment.datas))] if attachment and attachment.datas else None
                    )
                    success_count += 1
                except Exception as e:
                    _logger.error("❌ Error publicando en lead %s: %s", lead.id, e)

            _logger.info("✅ Mensaje de grupo publicado en %s leads", success_count)
            return True
            
        except Exception as e:
            _logger.error("❌ Error procesando mensaje de grupo: %s", e)
            return False

    def _download_and_save_media(self, url, media_type, mime_type, filename):
        """Descarga archivo desde URL y lo guarda como ir.attachment."""
        if not url:
            return False
            
        try:
            _logger.info("📥 Descargando media desde: %s", url[:100])
            
            # Obtener credenciales para requests autenticados si es URL de APIChat
            ICP = self.env['ir.config_parameter'].sudo()
            headers = {}
            if 'apichat.io' in url.lower():
                client_id = ICP.get_param('apichat.client_id')
                token = ICP.get_param('apichat.token')
                if client_id and token:
                    headers = {'client-id': client_id, 'token': token}
            
            resp = requests.get(url, headers=headers, timeout=60)
            
            if not resp.ok:
                _logger.error("❌ Error descargando media: HTTP %s", resp.status_code)
                return False
            
            # Determinar nombre y tipo MIME
            if not filename:
                # Intentar obtener del Content-Disposition o generar uno
                content_disp = resp.headers.get('Content-Disposition', '')
                if 'filename=' in content_disp:
                    import re as re_mod
                    match = re_mod.search(r'filename[*]?=(?:UTF-8\'\')?(["\']?)(.+?)\1(?:;|$)', content_disp)
                    if match:
                        filename = match.group(2)
                
                if not filename:
                    ext_map = {
                        'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp',
                        'application/pdf': '.pdf',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
                    }
                    detected_mime = mime_type or resp.headers.get('Content-Type', '').split(';')[0]
                    ext = ext_map.get(detected_mime, '.bin')
                    filename = f"whatsapp_{media_type}_{fields.Datetime.now().strftime('%Y%m%d_%H%M%S')}{ext}"
            
            if not mime_type:
                mime_type = resp.headers.get('Content-Type', 'application/octet-stream').split(';')[0]
            
            # Crear attachment
            attachment = self.env['ir.attachment'].sudo().create({
                'name': filename,
                'type': 'binary',
                'datas': base64.b64encode(resp.content),
                'mimetype': mime_type,
                'public': False,
            })
            
            _logger.info("✅ Media guardada como attachment ID: %s (%s bytes)", attachment.id, len(resp.content))
            return attachment
            
        except requests.Timeout:
            _logger.error("⏱️ Timeout descargando media desde: %s", url[:100])
        except requests.RequestException as e:
            _logger.error("❌ Error de conexión descargando media: %s", e)
        except Exception as e:
            _logger.error("❌ Error inesperado descargando media: %s", e)
        
        return False

    def _download_media_from_evolution(self, message_id, media_type, mime_type, filename, message=None):
        """Descarga archivo multimedia usando Evolution API endpoint /chat/getBase64FromMediaMessage."""
        if not message_id:
            _logger.error("❌ No se puede descargar media sin messageId")
            return False
            
        try:
            # Obtener credenciales de Evolution API
            ICP = self.env['ir.config_parameter'].sudo()
            base_url = ICP.get_param('evolution.api_url', '').strip().rstrip('/')
            api_key = ICP.get_param('evolution.api_key', '').strip()
            instance = ICP.get_param('evolution.instance_name', '').strip()
            
            if not base_url or not api_key or not instance:
                _logger.error("❌ Credenciales de Evolution API no configuradas correctamente")
                return False
            
            # Construir URL del endpoint
            url = f"{base_url}/chat/getBase64FromMediaMessage/{instance}"
            
            headers = {
                'apikey': api_key,
                'Content-Type': 'application/json'
            }
            
            # Evolution API v2.3.7 espera el OBJETO DEL MENSAJE COMPLETO, no solo el key
            # Según el error "Cannot read properties of undefined (reading 'key')", 
            # significa que está buscando message.key, no directamente la key
            if message:
                payload = {
                    'message': message,  # Enviar el mensaje completo
                    'convertToMp4': False  # Mantener formato original
                }
            else:
                # Fallback si no tenemos el mensaje completo (no debería pasar)
                payload = {
                    'message': {
                        'key': {
                            'id': message_id
                        }
                    },
                    'convertToMp4': False
                }
            
            resp = requests.post(url, json=payload, headers=headers, timeout=60)
            
            if not resp.ok:
                _logger.error("❌ Error al obtener media desde Evolution API: HTTP %s - %s", resp.status_code, resp.text[:200])
                return False
            
            try:
                result = resp.json()
            except Exception as e:
                _logger.error("❌ Respuesta no es JSON válido: %s", e)
                return False
            
            # Evolution API devuelve: { "base64": "...", "mimetype": "..." }
            # O puede devolver directamente el base64 como string
            if isinstance(result, dict):
                base64_content = result.get('base64') or result.get('data')
                detected_mime = result.get('mimetype') or result.get('mimeType') or mime_type
            elif isinstance(result, str):
                base64_content = result
                detected_mime = mime_type
            else:
                _logger.error("❌ Formato de respuesta inesperado: %s", type(result))
                return False
            
            if not base64_content:
                _logger.error("❌ No se recibió contenido base64 en la respuesta")
                return False
            
            # Determinar extensión y tipo MIME si no están disponibles
            if not detected_mime or not filename:
                # Mapeo de tipos de mensaje a extensiones y mimetypes
                type_map = {
                    'image': ('jpg', 'image/jpeg'),
                    'imageMessage': ('jpg', 'image/jpeg'),
                    'video': ('mp4', 'video/mp4'),
                    'videoMessage': ('mp4', 'video/mp4'),
                    'audio': ('ogg', 'audio/ogg'),
                    'audioMessage': ('ogg', 'audio/ogg'),
                    'document': ('pdf', 'application/pdf'),
                    'documentMessage': ('pdf', 'application/pdf'),
                }
                
                def_ext, def_mime = type_map.get(media_type, ('bin', 'application/octet-stream'))
                
                if not detected_mime:
                    detected_mime = def_mime
                    
                if not filename or filename == 'file.enc':
                    import time
                    timestamp = int(time.time())
                    filename = f"whatsapp_{media_type}_{timestamp}.{def_ext}"
            
            # Limpiar el base64 si tiene prefijo data:
            if base64_content.startswith('data:'):
                # Formato: data:image/jpeg;base64,/9j/4AAQ...
                base64_content = base64_content.split(',', 1)[1] if ',' in base64_content else base64_content
            
            # Crear attachment
            attachment = self.env['ir.attachment'].sudo().create({
                'name': filename,
                'type': 'binary',
                'datas': base64_content,
                'mimetype': detected_mime,
                'public': False,
            })
            
            _logger.info("✅ Evolution API → %s", filename)
            return attachment
            
        except requests.Timeout:
            _logger.error("⏱️ Timeout descargando media desde Evolution API")
        except requests.RequestException as e:
            _logger.error("❌ Error de conexión con Evolution API: %s", e)
        except Exception as e:
            _logger.error("❌ Error inesperado descargando media desde Evolution API: %s", e)
            import traceback
            _logger.error(traceback.format_exc())
        
        return False

    def _process_incoming_message_crm_and_partner(self, norm_msisdn, body_text, message_type, timestamp, attachment=None, media_type='text'):
        try:
            partner = self._find_partner_by_phone(norm_msisdn)
            lead = self._find_lead_by_phone_or_partner(norm_msisdn, partner=partner)
            applicant = self._find_applicant_by_phone_or_partner(norm_msisdn, partner=partner)
            
            # Fallback: Si no encontramos partner directo, pero el lead/applicant tiene uno, usémoslo
            if not partner:
                if lead and lead.partner_id:
                    partner = lead.partner_id
                    _logger.info("🔗 Partner %s recuperado desde Lead %s", partner.name, lead.id)
                elif applicant and applicant.partner_id:
                    partner = applicant.partner_id
                    _logger.info("🔗 Partner %s recuperado desde Applicant %s", partner.name, applicant.id)
            
            if not lead and not applicant and not partner:
                _logger.info("🚫 Mensaje ignorado: no existe lead, applicant ni partner para %s", norm_msisdn)
                return False

            records_to_notify = []
            if lead: records_to_notify.append({'record': lead, 'model': 'crm.lead', 'name': lead.name})
            if applicant: records_to_notify.append({'record': applicant, 'model': 'hr.applicant', 'name': applicant.partner_name or applicant.name})
            if partner: records_to_notify.append({'record': partner, 'model': 'res.partner', 'name': partner.name})
            
            # Buscar proyectos activos del contacto
            if partner:
                projects = self._find_projects_by_partner(partner)
                for project in projects:
                    records_to_notify.append({'record': project, 'model': 'project.project', 'name': project.name})

            author_pid = partner.id if partner else None
            if not author_pid and records_to_notify and getattr(records_to_notify[0]['record'], 'partner_id', False):
                author_pid = records_to_notify[0]['record'].partner_id.id

            icp = self.env['ir.config_parameter'].sudo()
            simple = (icp.get_param('apichatv4.simple_body', '1') or '1').strip().lower() in ('1', 'true', 'yes', 'y')
            
            _logger.info("📋 Registros a notificar para %s: %s", norm_msisdn, [r['name'] for r in records_to_notify])

            # Construir body del mensaje
            if simple:
                body = _esc((body_text or '').strip())
            else:
                body = self._create_message_html(norm_msisdn, body_text, message_type, timestamp)
            
            # Añadir info de media si existe
            if attachment and media_type != 'text':
                media_icon = "🖼️" if media_type == 'image' else "📄"
                body = f"{media_icon} <b>{attachment.name}</b><br/>{body}" if body else f"{media_icon} <b>{attachment.name}</b>"

            success_count = 0
            for item in records_to_notify:
                if self._message_post(item['record'], body, item['model'], author_partner_id=author_pid, original_attachment=attachment if attachment else None):
                    success_count += 1
                    _logger.info("✅ Mensaje publicado en %s: %s", item['model'], item['name'])
                else:
                    _logger.warning("⚠️ Falló publicación en %s: %s", item['model'], item['name'])
                    
            return success_count > 0
        except Exception as e:
            _logger.error("❌ Error procesando mensaje entrante: %s", e)
            return False

    def _find_partner_by_phone(self, phone):
        Partner = self.env['res.partner'].sudo()
        d = _digits(phone)
        domains = []
        for pat in self._mk_patterns(d):
            domains.append(('phone', 'ilike', pat))
            if 'mobile' in Partner._fields:
                domains.append(('mobile', 'ilike', pat))
        
        domain = ['|'] * (len(domains) - 1) + domains if len(domains) > 1 else domains
        partner = Partner.search(domain, limit=1) if domain else False
        _logger.info("🔎 Buscando partner por teléfono %s -> Encontrado: %s", phone, partner.name if partner else "NO")
        return partner

    def _base_lead_domain(self):
        base = [('active', '=', True)]
        if 'lost' in self.env['crm.lead']._fields:
            base.append(('lost', '=', False))
        return base

    def _find_lead_by_phone_or_partner(self, phone_number, partner=None):
        Lead = self.env['crm.lead'].sudo()
        if partner:
            domain = self._base_lead_domain() + [('partner_id', '=', partner.id)]
            lead = Lead.search(domain, order='write_date desc, id desc', limit=1)
            if lead: return lead
            
        d = _digits(phone_number)
        patterns = self._mk_patterns(d)
        _logger.info("🔎 Buscando Lead con patrones: %s (digits: %s)", patterns, d)
        
        for pat in patterns:
            conditions = self._base_lead_domain()
            phone_conds = []
            if 'phone' in Lead._fields: phone_conds.append(('phone', 'ilike', pat))
            if 'mobile' in Lead._fields: phone_conds.append(('mobile', 'ilike', pat))
            
            # Buscar también en el partner relacionado (phone y mobile)
            phone_conds.append(('partner_id.phone', 'ilike', pat))
            if 'mobile' in self.env['res.partner']._fields:
                phone_conds.append(('partner_id.mobile', 'ilike', pat))
            
            if phone_conds:
                domain = conditions + ['|'] * (len(phone_conds) - 1) + phone_conds
                # _logger.info("  Testing Domain: %s", domain)
                lead = Lead.search(domain, order='write_date desc, id desc', limit=1)
                if lead: 
                    _logger.info("  ✅ Lead encontrado: %s (id %s)", lead.name, lead.id)
                    return lead
        return None

    def _find_applicant_by_phone_or_partner(self, phone_number, partner=None):
        Applicant = self.env['hr.applicant'].sudo()
        if partner:
            domain = [('active', '=', True), ('partner_id', '=', partner.id)]
            applicant = Applicant.search(domain, order='write_date desc, id desc', limit=1)
            if applicant: return applicant
            
        d = _digits(phone_number)
        for pat in self._mk_patterns(d):
            conditions = [('active', '=', True)]
            phone_conds = []
            if 'partner_phone' in Applicant._fields: phone_conds.append(('partner_phone', 'ilike', pat))
            if 'partner_mobile' in Applicant._fields: phone_conds.append(('partner_mobile', 'ilike', pat))
            phone_conds.append(('partner_id.phone', 'ilike', pat))
            
            if phone_conds:
                domain = conditions + ['|'] * (len(phone_conds) - 1) + phone_conds
                applicant = Applicant.search(domain, order='write_date desc, id desc', limit=1)
                if applicant: return applicant
        return None

    def _find_projects_by_partner(self, partner):
        """Busca proyectos activos asociados al partner o su compañía."""
        if not partner:
            return []
            
        partner_ids = [partner.id]
        if partner.parent_id:
            partner_ids.append(partner.parent_id.id)
            
        projects = self.env['project.project'].sudo().search([
            ('partner_id', 'in', partner_ids),
            ('active', '=', True)
        ])
        _logger.info("🔍 Proyectos encontrados para partner %s (ids %s): %s", partner.name, partner_ids, projects.ids)
        return projects

    def _mk_patterns(self, d):
        d = (d or '').strip()
        tails = []
        for n in (11, 10, 9, 8, 7):
            if len(d) >= n: tails.append(d[-n:])
        patterns = []
        for t in tails:
            patterns.append(t)
            patterns.append('%' + '%'.join(t) + '%')
        return patterns

    def _create_message_html(self, from_msisdn, body_text, message_type, timestamp):
        try:
            when = datetime.fromtimestamp(int(timestamp), timezone.utc).strftime('%Y-%m-%d %H:%M:%S') if timestamp else datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
        except:
            when = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
            
        parts = [f"📩 <b>WhatsApp</b> de <b>{_esc(from_msisdn)}</b> <span style='color:#888'>({_esc(when)} UTC)</span>"]
        if message_type and message_type != 'text': parts.append(f"<br/><b>Tipo:</b> {_esc(message_type)}")
        if body_text: parts.append(f"<br/><b>Mensaje:</b> {_esc(body_text)}")
        return ''.join(parts)

    def _message_post(self, record, body, model_name, author_partner_id=None, attachment_ids=None, original_attachment=None):
        try:
            if not author_partner_id:
                author_partner_id = self.env.ref('base.partner_root').id
            
            record_sudo = record.sudo().with_context(mail_create_nosubscribe=False, mail_post_autofollow=True)
            if not hasattr(record_sudo, 'message_post'): return False
            
            # Suscribir usuario asignado
            user = getattr(record_sudo, 'user_id', None)
            if user and user.partner_id:
                try: record_sudo.message_subscribe(partner_ids=[user.partner_id.id])
                except: pass
            
            # Preparar kwargs para message_post
            # Usar Markup para que el HTML se renderice correctamente en Odoo 17+
            safe_body = Markup(body) if body else ''
            post_kwargs = {
                'body': safe_body,
                'message_type': 'comment',
                'subtype_xmlid': 'mail.mt_comment',
                'author_id': author_partner_id,
            }
            
            # Si hay attachment original, adjuntarlo al mensaje usando el parámetro 'attachments'
            # que acepta lista de tuplas (filename, content_bytes)
            if original_attachment:
                try:
                    # Decodificar el contenido del attachment
                    file_content = base64.b64decode(original_attachment.datas) if original_attachment.datas else b''
                    if file_content:
                        # Usar 'attachments' en lugar de 'attachment_ids' para adjuntar directamente
                        post_kwargs['attachments'] = [(original_attachment.name, file_content)]
                        _logger.info("📎 Adjuntando archivo a mensaje en %s (id=%s): %s (%s bytes)", 
                                    model_name, record.id, original_attachment.name, len(file_content))
                    else:
                        _logger.warning("⚠️ Attachment sin contenido: %s", original_attachment.name)
                except Exception as att_e:
                    _logger.error("❌ Error procesando attachment: %s", att_e)
            elif attachment_ids:
                post_kwargs['attachment_ids'] = attachment_ids
                
            msg = record_sudo.message_post(**post_kwargs)
            return bool(msg)
        except Exception as e:
            _logger.error("❌ Error publishing message: %s", e)
            return False