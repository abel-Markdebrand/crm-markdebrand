
import requests
import sys

# CONFIGURACION
CLIENT_ID = "30280" 
TOKEN = "SATsZ8abRYMN"

if len(sys.argv) > 2:
    CLIENT_ID = sys.argv[1]
    TOKEN = sys.argv[2]

print(f"🔍 TESTING PAGINATION - Instance: {CLIENT_ID}")
print("-" * 60)

base_url = f"https://api.apichat.io/instance{CLIENT_ID}/dialogs"

# Vamos a pedir 1 chat, y luego pedir la pagina 2 para ver si es diferente
print("👉 Petición 1: limit=1, page=1")
url1 = f"{base_url}?token={TOKEN}&limit=1&page=1"
try:
    resp1 = requests.get(url1, timeout=20)
    data1 = resp1.json()
    chat1_id = data1[0]['id'] if data1 and isinstance(data1, list) and len(data1) > 0 else None
    print(f"   Chat 1 ID: {chat1_id}")
except Exception as e:
    print(f"   Error: {e}")
    chat1_id = None

if chat1_id:
    print("\n👉 Petición 2: limit=1, page=2 (Testing 'page' param)")
    url2 = f"{base_url}?token={TOKEN}&limit=1&page=2"
    try:
        resp2 = requests.get(url2, timeout=20)
        data2 = resp2.json()
        chat2_id = data2[0]['id'] if data2 and isinstance(data2, list) and len(data2) > 0 else None
        print(f"   Chat 2 ID: {chat2_id}")
        
        if chat1_id != chat2_id:
            print("   ✅ PAGINATION 'page' WORKS! (IDs are different)")
        else:
            print("   ⚠️ Los IDs son iguales. 'page' param might be ignored.")
            
            # Pruebo offset
            print("\n👉 Petición 3: limit=1, offset=1 (Testing 'offset' param)")
            url3 = f"{base_url}?token={TOKEN}&limit=1&offset=1"
            resp3 = requests.get(url3, timeout=20)
            data3 = resp3.json()
            chat3_id = data3[0]['id'] if data3 and isinstance(data3, list) and len(data3) > 0 else None
            print(f"   Chat 3 ID: {chat3_id}")
            
            if chat1_id != chat3_id:
                 print("   ✅ PAGINATION 'offset' WORKS!")
            else:
                 print("   ❌ Neither 'page' nor 'offset' seems to work.")

    except Exception as e:
        print(f"   Error: {e}")
