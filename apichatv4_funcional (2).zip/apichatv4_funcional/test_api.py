import requests
import json
import sys

# Configuración (Reemplazar con los valores reales si se conocen, o se pasan por argumento)
API_BASE = "https://api.apichat.io"
# Puedes pasar client_id y token como argumentos: python test_api.py CLIENT_ID TOKEN
CLIENT_ID = sys.argv[1] if len(sys.argv) > 1 else ""
TOKEN = sys.argv[2] if len(sys.argv) > 2 else ""

if not CLIENT_ID or not TOKEN:
    print("❌ Error: Debes proporcionar Client ID y Token.")
    print("Uso: python test_api.py <CLIENT_ID> <TOKEN>")
    sys.exit(1)

headers = {
    "client-id": CLIENT_ID,
    "token": TOKEN,
    "Content-Type": "application/json"
}

endpoints = [
    "/v1/dialogs",
    "/dialogs",
    "/v1/chats",
    "/chats",
    "/v1/groups",
    "/groups",
    "/v1/contacts",
    "/contacts",
    "/v1/getDialogs",
    "/v1/getChats",
]

print(f"🔍 Probando conexión con Client ID: {CLIENT_ID}")
print("-" * 50)

for ep in endpoints:
    url = f"{API_BASE}{ep}"
    print(f"👉 Probando: {url}")
    try:
        # Intentar GET
        resp = requests.get(url, headers=headers, timeout=10)
        print(f"   GET Status: {resp.status_code}")
        
        if resp.ok:
            print("   ✅ ¡ÉXITO! (GET)")
            print(f"   Respuesta: {resp.text[:200]}...")
            continue
            
        # Si falla, intentar POST (algunas APIs son raras)
        if resp.status_code in [404, 405]:
            resp = requests.post(url, headers=headers, timeout=10)
            print(f"   POST Status: {resp.status_code}")
            if resp.ok:
                print("   ✅ ¡ÉXITO! (POST)")
                print(f"   Respuesta: {resp.text[:200]}...")
            
    except Exception as e:
        print(f"   ❌ Error: {e}")

print("-" * 50)
